"""The five Susanoo stages as smooth meshes, laid out exactly like the cube versions the user liked."""
import math

import numpy as np

from mesh import Mesh, V, circle, lerp, rot, superellipse, unit
from parts import (ROUND, SOFTBOX, arc, band, bone_beam, dome_plate, facing, finger_hand, flame_rise, flame_skirt, flame_tongue,
                   katana, limb, plate, ribcage, skeletal_hand, skull, spine, wing, claw_hand)


def curved_rect(n=20, p=5.0, bend=1.6):
    """A plate's cross-section: a rounded rectangle bowed outward (+y) in the middle."""
    out = []
    for x, y in superellipse(n, p):
        out.append((x, y - bend * (x * x - 0.35)))
    return out


# ================================================================ 1. Ribcage (about 4 blocks tall, around the user)

def stage1():
    m = Mesh("susanoo_stage1", scale=1.0)
    m.bone("root")
    m.bone("body", "root", (0, 8, -18))
    spine(m, "body", 0, 4, 64, -22, 6, 4.4)
    ys = [62, 55.5, 49, 42.5, 36, 30, 25]
    rxs = [13, 18, 21.5, 23.5, 24, 23, 20]
    rzs = [15, 20, 23, 24.5, 25, 24, 21]
    ribcage(m, "body", (0, 0, -1), ys, rxs, rzs, -22, thick=(2.8, 1.7), droop=12, open_front=34, floating=2, segs=9)
    # breastbone, with the cartilage of each true rib curving in to it
    m.sweep("body", "bone", [(0, 58, 21.4), (0, 46, 22.4), (0, 33, 21.8)], lambda t: (6.5 - 2.5 * t, 2.6),
            profile=superellipse(14, 3), hint=(1, 0, 0), n=4)
    m.blob("body", "bone", (0, 58.5, 21.3), (9.5, 6.5, 3.2), e=ROUND, seg=(14, 8))
    m.blob("body", "bone", (0, 30, 21.6), (2.6, 4.5, 2), e=(1, 1), seg=(10, 6))
    for i in range(5):
        y = ys[i] - 12
        for sx in (-1, 1):
            a = math.radians(34) * sx
            end = V(math.sin(a) * rxs[i], y, -1 + math.cos(a) * rzs[i])
            to = V(sx * 3, ys[i] - 5 - i * 1.5, 22)
            m.sweep("body", "bone", [end, lerp(end, to, 0.5) + V(0, -1.5, 1.2), to], (2.2, 1.8), n=4, profile=circle(8))
    for sx in (-1, 1):                                  # S-curved collarbones and flat shoulder blades
        m.sweep("body", "bone", [(sx * 4, 61, 20), (sx * 11, 63.5, 13), (sx * 17, 63, 4), (sx * 21, 64, -4)],
                lambda t: (2.7 * (1 - 0.2 * math.sin(math.pi * t)),) * 2, n=4, profile=circle(10))
        m.blob("body", "bone", (sx * 21, 64, -4), (4.2, 3.6, 4.2), e=ROUND, seg=(12, 8))
        R = rot(6, -sx * 14, 0)
        c = V(sx * 12, 51, -25)
        m.blob("body", "bone", c, (10.5, 15, 2.2), R=R, e=(0.9, 0.55), seg=(14, 8))
        m.sweep("body", "bone", [c + R @ V(-5, 6, -1), c + R @ V(5, 6.5, -1.6)], (2.2, 2.4), n=3, profile=circle(8))
    for i in range(9):                                  # chakra flames licking up around the base
        a = math.radians(-100 + i * 25)
        flame_rise(m, "body", (math.sin(a) * 17, 0, -6 + math.cos(a) * 17), 10 + (i * 7) % 9, 7, (math.sin(a), math.cos(a)))
    return m


# ================================================================ 2. Skeletal upper body (about 7 blocks)

def skeleton_upper(m, parent, s=1.0, prefix="", z0=0.0, pose="ready", mat="bone"):
    S = s
    p = prefix
    spine(m, parent, 0, 4 * S, 98 * S, -26 * S + z0, 8 * S, 6 * S, mat)
    ys = [y * S for y in (88, 82, 76, 70, 64, 58, 52, 47, 43)]
    rxs = [r * S for r in (18, 23, 27, 29, 30, 30, 29, 26, 22)]
    rzs = [r * S for r in (19, 24, 27, 29, 30, 30, 29, 27, 24)]
    ribcage(m, parent, (0, 0, -4 * S + z0), ys, rxs, rzs, -26 * S + z0, thick=(3.8 * S, 2.3 * S), droop=9 * S, open_front=22,
            mat=mat, segs=10)
    m.sweep(parent, mat, [(0, 86 * S, 25.5 * S + z0), (0, 72 * S, 26.4 * S + z0), (0, 59 * S, 25.6 * S + z0)],
            lambda t: ((8 - 3 * t) * S, 3 * S), profile=superellipse(14, 3), hint=(1, 0, 0), n=4)
    m.blob(parent, mat, (0, 87 * S, 25.3 * S + z0), (11 * S, 7 * S, 3.4 * S), e=ROUND, seg=(14, 8))
    for sx in (-1, 1):
        m.sweep(parent, mat, [(sx * 4 * S, 90 * S, 23 * S + z0), (sx * 15 * S, 93 * S, 15 * S + z0), (sx * 27 * S, 93 * S, 4 * S + z0),
                              (sx * 36 * S, 94 * S, -6 * S + z0)], (4.2 * S, 4.2 * S), n=4, profile=circle(10))
        R = rot(10, -sx * 22, 0)
        c = V(sx * 18 * S, 80 * S, -29 * S + z0)
        m.blob(parent, mat, c, (18 * S, 25 * S, 2.6 * S), R=R, e=(0.9, 0.55), seg=(16, 8))
        m.sweep(parent, mat, [c + R @ V(-9 * S, 9 * S, -1.5 * S), c + R @ V(9 * S, 9.5 * S, -2 * S)], (3 * S, 3.2 * S), n=3,
                profile=circle(8))
    m.bone(p + "head", parent, (0, 98 * S, -18 * S + z0))
    m.bone(p + "jaw", p + "head", (0, 112 * S, -8 * S + z0))
    for i in range(4):                                  # neck vertebrae
        m.blob(p + "head", mat, (0, (99.5 + i * 4) * S, (-18 + i * 2) * S + z0), (7.5 * S, 3.2 * S, 7.5 * S), e=(0.7, 0.8), seg=(12, 6))
    skull(m, p + "head", p + "jaw", (0, 122 * S, -6 * S + z0), 1.15 * S, mat=mat)
    for sx, name in ((-1, "r"), (1, "l")):
        sh = V(sx * 37 * S, 92 * S, -6 * S + z0)
        if pose == "ready":
            el = V(sx * 47 * S, 62 * S, 2 * S + z0)
            wr = V(sx * 40 * S, 42 * S, (24 if sx < 0 else 18) * S + z0)
        else:
            el = V(sx * 46 * S, 60 * S, -4 * S + z0)
            wr = V(sx * 44 * S, 32 * S, 4 * S + z0)
        arm, fore, hand = m.bone(f"{p}arm_{name}", parent, sh), m.bone(f"{p}fore_{name}", f"{p}arm_{name}", el), None
        m.blob(arm, mat, sh, (9.5 * S, 9 * S, 9.5 * S), e=(1, 1), seg=(14, 8))
        bone_beam(m, arm, sh, el, 6 * S, 8 * S, mat)
        for off in (-2.2, 2.2):                         # radius and ulna
            m.sweep(fore, mat, [el + V(off * S, 0, 0), wr + V(off * 0.6 * S, 0, 0)], lambda t: (3.2 * S * (1 - 0.2 * math.sin(math.pi * t)),) * 2,
                    n=8, profile=circle(8))
        hand = m.bone(f"{p}hand_{name}", fore, wr)
        claw_hand(m, hand, el, wr, 1.6 * S, sx, curl=28, mat=mat)


def stage2():
    m = Mesh("susanoo_stage2", scale=0.82)
    m.bone("root")
    m.bone("body", "root", (0, 40, -10))
    skeleton_upper(m, "body")
    for i in range(12):
        a = math.radians(i * 30)
        flame_rise(m, "body", (math.sin(a) * 22, 0, -8 + math.cos(a) * 20), 14 + (i * 7) % 12, 9, (math.sin(a), math.cos(a)))
    return m


# ================================================================ 3. Humanoid (about 10 blocks)

def humanoid_head(m, bone, c, S):
    """A fierce face: heavy brow, slanted glowing eyes, cheekbones, strong jaw, and a mane of flames swept back."""
    C = V(c)
    m.blob(bone, "muscle", C + V(0, 2 * S, -1 * S), (28 * S, 31 * S, 29 * S), e=(0.8, 0.85), seg=(24, 14))          # head
    m.blob(bone, "muscle", C + V(0, -11 * S, 4 * S), (22 * S, 10 * S, 22 * S), e=(0.6, 0.75), seg=(20, 10))         # jaw
    m.sweep(bone, "muscle", [C + V(-13 * S, 5.4 * S, 9 * S), C + V(-6.5 * S, 3.8 * S, 14.4 * S), C + V(0, 1.6 * S, 15.6 * S),
                             C + V(6.5 * S, 3.8 * S, 14.4 * S), C + V(13 * S, 5.4 * S, 9 * S)],
            (4.4 * S, 3.6 * S), hint=(0, 1, 0), n=4, profile=circle(10))                                             # frowning brow
    for sx in (-1, 1):
        m.blob(bone, "shadow", C + V(sx * 6 * S, -0.2 * S, 12.8 * S), (8.4 * S, 2.8 * S, 3 * S), R=rot(0, 0, sx * 18), e=(1.2, 1), seg=(12, 6))
        m.blob(bone, "eye", C + V(sx * 6 * S, -0.2 * S, 14.2 * S), (7.4 * S, 1.5 * S, 1.4 * S), R=rot(0, 0, sx * 18), e=(1.6, 1),
               seg=(14, 6))                                                                                          # slanted eyes                                                                                           # eyes
        m.blob(bone, "muscle", C + V(sx * 8.8 * S, -4.6 * S, 12.4 * S), (6 * S, 3.6 * S, 4 * S), R=rot(0, 0, sx * 20), e=ROUND, seg=(12, 8))  # cheekbones
    m.sweep(bone, "muscle", [C + V(0, 2 * S, 15 * S), C + V(0, -3 * S, 16.2 * S), C + V(0, -6 * S, 16.4 * S)],
            lambda t: (3.6 * S * (1 + 0.4 * t), 3 * S), hint=(1, 0, 0), n=4, profile=circle(8))                          # nose
    m.sweep(bone, "shadow", [C + V(-5.5 * S, -10.6 * S, 14.2 * S), C + V(-2.5 * S, -9.6 * S, 15.2 * S), C + V(2.5 * S, -9.6 * S, 15.2 * S),
                             C + V(5.5 * S, -10.6 * S, 14.2 * S)],
            lambda t: (1.6 * S * (0.6 + 0.4 * math.sin(math.pi * t)), 1.2 * S), hint=(0, 1, 0), n=4, profile=circle(8))   # grim mouth
    for i in range(7):                                  # flame mane
        a = math.radians(-60 + i * 20)
        top = C + V(math.sin(a) * 12 * S, 14 * S, -6 * S + math.cos(a) * 6 * S)
        tip = top + V(math.sin(a) * 10 * S, (6 + (i % 3) * 4) * S, -(20 + (i % 2) * 8) * S)
        mid = lerp(top, tip, 0.5) + V(0, 4 * S, 0)
        m.sweep(bone, "flame", [top, mid, tip], lambda t: (9 * S * (1 - t) ** 0.8 + 0.4, 6 * S * (1 - t) ** 0.8 + 0.3),
                profile=circle(10), hint=(1, 0, 0), cap1="point", n=5, twist=40)


def muscular_body(m, parent, s=1.0, z0=0.0, prefix="", arms=("sword", "sword"), head=True):
    """Chest, abs, shoulders, neck, head and two muscular arms, ending at the wrists: the hands (holding each
    Mangekyou's own weapons) are built by weapons.py onto the hand bones. Returns the arm joints."""
    S = s
    p = prefix
    t = m.bone(p + "torso", parent, (0, 100 * S, -6 * S + z0))
    m.blob(t, "muscle", (0, 124 * S, -6 * S + z0), (56 * S, 40 * S, 34 * S), e=(0.6, 0.75), seg=(28, 14))          # chest
    for sx in (-1, 1):
        m.blob(t, "muscle", (sx * 12.5 * S, 131 * S, 11.5 * S + z0), (25 * S, 16 * S, 9 * S), R=rot(0, 0, sx * 8), e=(0.65, 0.8), seg=(16, 10))  # pecs
        m.blob(t, "muscle", (sx * 25 * S, 118 * S, 2 * S + z0), (9 * S, 26 * S, 20 * S), e=ROUND, seg=(12, 10))          # lats
        m.sweep(t, "muscle", [(sx * 6 * S, 153 * S, -9 * S + z0), (sx * 18 * S, 148 * S, -8 * S + z0), (sx * 30 * S, 142 * S, -6 * S + z0)],
                lambda u: ((14 - 4 * u) * S, (9 - 2 * u) * S), hint=(0, 0, 1), n=4, profile=circle(12))                  # trapezius
        for row in range(3):                                                                                             # abs
            m.blob(t, "muscle", (sx * 5.6 * S, (99 - row * 9) * S, 9.5 * S + z0), (9.6 * S, 8 * S, 6 * S), e=(0.55, 0.7), seg=(12, 8))
        m.blob(t, "muscle", (sx * 18.5 * S, 90 * S, 1 * S + z0), (8 * S, 22 * S, 18 * S), e=ROUND, seg=(12, 10))         # obliques
    m.blob(t, "muscle", (0, 92 * S, -4 * S + z0), (36 * S, 32 * S, 25 * S), e=(0.7, 0.8), seg=(22, 12))                # belly
    m.blob(t, "muscle", (0, 73 * S, -4 * S + z0), (41 * S, 15 * S, 27 * S), e=(0.6, 0.8), seg=(22, 10))                # waist
    head_bone = m.bone(p + "head", t, (0, 156 * S, -6 * S + z0))
    m.sweep(head_bone, "muscle", [(0, 145 * S, -7 * S + z0), (0, 156 * S, -6 * S + z0), (0, 163 * S, -5 * S + z0)],
            lambda u: ((17 - 2 * u) * S, (16 - 2 * u) * S), n=4, profile=circle(14))                                   # neck
    if head:
        humanoid_head(m, head_bone, (0, 172 * S, -4 * S + z0), S)
    joints = {}
    for sx, name in ((-1, "r"), (1, "l")):
        sh = V(sx * 38 * S, 136 * S, -6 * S + z0)
        arm = m.bone(f"{p}arm_{name}", t, sh)
        pose = arms[0] if sx < 0 else arms[1]
        if pose == "sword":
            el, wr = V(sx * 50 * S, 104 * S, 8 * S + z0), V(sx * 40 * S, 88 * S, 40 * S + z0)
        elif pose == "shield":
            el, wr = V(sx * 50 * S, 104 * S, 4 * S + z0), V(sx * 38 * S, 96 * S, 34 * S + z0)
        elif pose == "greatsword":
            el, wr = V(sx * 46 * S, 104 * S, 12 * S + z0), V(sx * 7 * S, 92 * S, 40 * S + z0)
        else:
            el, wr = V(sx * 50 * S, 102 * S, 4 * S + z0), V(sx * 46 * S, 72 * S, 26 * S + z0)
        m.blob(arm, "muscle", sh + V(sx * 1.5 * S, -2 * S, 0) + unit(el - sh) * 4 * S, (21 * S, 21 * S, 27 * S),
               R=facing(el - sh), e=(0.9, 0.9), seg=(18, 12))                                                              # deltoid
        limb(m, arm, sh + V(0, -3 * S, 0), el, 16 * S, 12.5 * S, bulge=0.22, bulge_at=0.45)                               # upper arm
        m.blob(arm, "muscle", lerp(sh, el, 0.45) + unit(np.cross(el - sh, (sx, 0, 0))) * -3 * S, (11 * S, 13 * S, 11 * S),
               R=facing(el - sh), e=(1, 1), seg=(14, 8))                                                                 # bicep
        fore = m.bone(f"{p}fore_{name}", arm, el)
        m.blob(fore, "muscle", el, (13.5 * S, 13.5 * S, 13.5 * S), e=(1, 1), seg=(14, 8))                                # elbow
        limb(m, fore, el, wr + unit(wr - el) * -3 * S, 14 * S, 9.5 * S, bulge=0.18, bulge_at=0.25)                      # forearm
        m.bone(f"{p}hand_{name}", fore, wr)
        m.blob(fore, "muscle", wr, (10 * S, 10 * S, 10 * S), e=(1, 1), seg=(12, 8))                                     # wrist
        joints[name] = (sh, el, wr)
    return joints


def lower_flames(m, parent):
    flame_skirt(m, parent, 70, 17, 8, 54, 16)
    flame_tongue(m, parent, (0, 70, -4), 60, 22, 0, (0, 0), "flame", curl=0)
    for i in range(9):
        a = math.radians(i * 40 + 18)
        flame_rise(m, parent, (math.sin(a) * 20, 0, -4 + math.cos(a) * 18), 10 + (i * 7) % 9, 9, (math.sin(a), math.cos(a)))


def stage3():
    m = Mesh("susanoo_stage3", scale=0.8)
    m.bone("root")
    m.bone("body", "root", (0, 62, -6))
    joints = muscular_body(m, "body")
    m.bone("inner", "body", (0, 60, -6))               # the skeleton still shows faintly inside the chakra flesh
    ys = [140, 133, 126, 119, 112, 105, 99]
    rxs = [20, 24, 26, 27, 26, 24, 20]
    rzs = [14, 16, 17, 17.5, 17, 16, 14]
    ribcage(m, "inner", (0, 0, -5), ys, rxs, rzs, -18, thick=(3, 2), droop=7, open_front=24, mat="bone_inner", segs=8)
    spine(m, "inner", 0, 66, 150, -18, 6, 5, "bone_inner")
    lower_flames(m, "body")
    m.meta = {"joints": joints, "scale": 1.0, "offset": (0, 0, 0), "head": None}
    return m


# ================================================================ 4. Armored (about 14 blocks)

def armor_upper(m, joints, s=1.0, z0=0.0, prefix="", helmet=True):
    S = s
    p = prefix
    t = p + "torso"
    m.blob(t, "armor", (0, 127 * S, -5.5 * S + z0), (62 * S, 39 * S, 41 * S), e=(0.5, 0.62), seg=(30, 14))           # breastplate
    band(m, t, "trim", arc((0, 0, -5.5 * S + z0), 29.5 * S, 20.8 * S, 139 * S, 139 * S, -62, 62, 10), 5 * S, 2.6 * S)
    m.sweep(t, "trim", [(0, 145 * S, 14.6 * S + z0), (0, 130 * S, 15.6 * S + z0), (0, 113 * S, 14.4 * S + z0)], (4 * S, 2.2 * S),
            profile=superellipse(14, 4), hint=(1, 0, 0), n=4)                                                         # centre ridge
    for i in range(4):                                                                                                 # stomach lames
        y = (104 - i * 8) * S
        band(m, t, "armor", arc((0, 0, -3 * S + z0), (25.5 - i) * S, (18.5 - 0.5 * i) * S, y, y, -120, 120, 12, droop=2 * S),
             7.4 * S, 2.6 * S)
    for sx, name in ((-1, "r"), (1, "l")):                                                                             # pauldrons
        arm = f"{p}arm_{name}"
        for i in range(3):
            tilt = math.radians(20 + 9 * i)
            x0 = sx * (40 + 4.5 * i) * S
            y0 = (141 - 8 * i) * S
            r = (15 + 2.2 * i) * S
            pts = [V(x0, y0 + math.cos(math.radians(a)) * r, -6 * S + z0 + math.sin(math.radians(a)) * r * 1.1) for a in range(-80, 81, 20)]
            m.sweep(arm, "trim" if i == 0 else "armor", pts, ((30 + 3 * i) * S, 3 * S), profile=curved_rect(14, 6, -1.0),
                    hint=(sx * math.cos(tilt), -math.sin(tilt), 0), n=2)
        sh, el, wr = joints[name]
        d = wr - el
        a, b = el + d * 0.32, el + d * 0.86                                                                           # bracer
        m.sweep(f"{p}fore_{name}", "armor", [a, b], lambda u: ((15.5 + 2 * u) * S, (15.5 + 2 * u) * S), cap0="flat", cap1="flat",
                n=6, profile=superellipse(16, 3))
        m.sweep(f"{p}fore_{name}", "trim", [b - unit(d) * 1.4 * S, b + unit(d) * 1.4 * S], (19.5 * S, 19.5 * S), cap0="flat",
                cap1="flat", n=2, profile=superellipse(16, 3))
    if helmet:
        h = p + "head"
        x, y, z = 0, 172 * S, -4 * S + z0
        C = V(x, y, z)
        m.blob(h, "armor", C + V(0, 7 * S, -1 * S), (35 * S, 30 * S, 36 * S), e=(0.85, 0.9), v_range=(0, 90), seg=(26, 8))   # bowl
        m.sweep(h, "trim", [C + V(0, 7 * S + 15 * S * math.sin(math.radians(a)), -1 * S + 18 * S * math.cos(math.radians(a)))
                            for a in range(20, 161, 20)], (2.4 * S, 2.6 * S), n=3, profile=circle(8))               # crown ridge
        band(m, h, "trim", arc((x, 0, z - 1 * S), 18.2 * S, 18.6 * S, y + 7 * S, y + 7 * S, -80, 80, 10), 2.4 * S, 6 * S)  # brim
        for i in range(3):                                                                                             # neck guard
            r = (18.5 + 3.2 * i) * S
            band(m, h, "armor", arc((x, 0, z - 3 * S), r, r * 0.95, y + (3 - i * 6.2) * S, y + (3 - i * 6.2) * S, 75, 285, 12),
                 6.2 * S, 2.2 * S)
        m.blob(h, "armor", C + V(0, -8 * S, 14.2 * S), (24 * S, 13 * S, 7 * S), e=(0.6, 0.8), seg=(18, 10))         # face guard
        m.sweep(h, "shadow", [C + V(-6 * S, -10 * S, 17.6 * S), C + V(0, -9.6 * S, 18.1 * S), C + V(6 * S, -10 * S, 17.6 * S)],
                (1.2 * S, 1.0 * S), hint=(0, 1, 0), n=3, profile=circle(8))
        for sx in (-1, 1):
            m.blob(h, "armor", C + V(sx * 11.5 * S, -5 * S, 11.5 * S), (5.5 * S, 17 * S, 9 * S), R=rot(0, sx * 12, 0), e=(0.5, 0.7), seg=(12, 10))
        m.blob(h, "trim", C + V(0, 11.5 * S, 17.2 * S), (7 * S, 9 * S, 3 * S), e=(0.55, 0.7), seg=(12, 8))         # crest plate
        for sx in (-1, 1):                                                                                             # crest horns
            base = C + V(sx * 3 * S, 13 * S, 17.5 * S)
            m.sweep(h, "trim", [base, C + V(sx * 11 * S, 22 * S, 16 * S), C + V(sx * 15.5 * S, 32 * S, 12.5 * S), C + V(sx * 15 * S, 40 * S, 8 * S)],
                    lambda u: (6.5 * S * (1 - u) ** 0.7 + 0.3, 2 * S * (1 - 0.5 * u)), profile=circle(10), hint=(1, 0, 0),
                    cap1="point", n=5)


def kusazuri(m, bone, y_top, radius, count, length, s=1.0, z0=0.0):
    """Hanging waist plates around the hips, each bowed outward, with a trim edge along the bottom."""
    for i in range(count):
        a = math.radians(i * 360 / count)
        out = V(math.sin(a), 0, math.cos(a))
        tang = V(math.cos(a), 0, -math.sin(a))
        top = V(math.sin(a) * radius, y_top, math.cos(a) * radius - 4 * s + z0)
        bottom = top + out * 9 * s + V(0, -length, 0)
        mid = lerp(top, bottom, 0.5) + out * 0.8 * s
        wid = min(19 * s, 2 * math.pi * radius / count * 0.86)
        m.sweep(bone, "armor", [top, mid, bottom], lambda u: (wid * (0.9 + 0.18 * u), 3 * s), profile=curved_rect(14, 6, 1.4),
                hint=tang, n=4)
        edge = bottom + V(0, 1.6 * s, 0) + out * 0.4 * s
        hw = wid * 0.53
        m.sweep(bone, "trim", [edge - tang * hw - out * 1.0 * s, edge + out * 0.6 * s, edge + tang * hw - out * 1.0 * s],
                (3.2 * s, 3.8 * s), profile=superellipse(8, 4), hint=(0, 1, 0), n=2)


def shield(m, bone, center, s=1.0):
    """A round, domed shield with a rim, a boss and a cross of straps, worn on the forearm."""
    R = rot(0, 20, 0)
    c = V(center)
    m.blob(bone, "armor", c, (40 * s, 40 * s, 7 * s), R=R, e=(0.9, 1.0), seg=(28, 12))
    ring = [c + R @ V(19.5 * s * math.cos(2 * math.pi * k / 24), 19.5 * s * math.sin(2 * math.pi * k / 24), 0.6 * s) for k in range(25)]
    m.sweep(bone, "trim", ring, (3.2 * s, 3.2 * s), cap0=None, cap1=None, n=2, profile=circle(10))
    m.blob(bone, "trim", c + R @ V(0, 0, 3.2 * s), (12 * s, 12 * s, 6 * s), R=R, e=(1, 1), seg=(16, 8))
    for ax in ((1, 0), (0, 1)):
        pts = [c + R @ V(ax[0] * u * s, ax[1] * u * s, 3.3 * s * (1 - (u / 19.5) ** 2) + 0.2 * s) for u in range(-18, 19, 4)]
        m.sweep(bone, "trim", pts, (2.4 * s, 1.0 * s), profile=superellipse(12, 4), hint=R @ V(ax[1], ax[0], 0), n=2)


def stage4():
    m = Mesh("susanoo_stage4", scale=1.05)
    m.bone("root")
    m.bone("body", "root", (0, 62, -6))
    joints = muscular_body(m, "body")
    armor_upper(m, joints)
    lower_flames(m, "body")
    kusazuri(m, "torso", 74, 25, 9, 34)
    m.meta = {"joints": joints, "scale": 1.0, "offset": (0, 0, 0), "head": None}
    return m


# ================================================================ 5. Perfect (about 24 blocks, 40-block wingspan)

def graft(dst, src, parent, scale, offset, skip=()):
    """Copies src's pieces and bones into dst under parent, scaled about the origin then moved by offset."""
    off = V(offset)
    for name in src.order:
        if name in skip:
            continue
        b = src.bones[name]
        par = b["parent"] if b["parent"] not in skip else parent
        dst.bone(name, par, list(V(b["pivot"]) * scale + off))
    for pc in src.pieces:
        bone = pc["bone"] if pc["bone"] not in skip else parent
        dst.pieces.append({"bone": bone, "mat": pc["mat"], "V": pc["V"] * scale + off, "F": pc["F"].copy(), "UV": pc["UV"].copy()})


def stage5():
    m = Mesh("susanoo_stage5", scale=1.9)
    S = 0.75
    m.bone("root")
    lift = 86
    m.bone("hips", "root", (0, lift, 0))
    m.bone("body", "hips", (0, lift + 4, -4))
    up = Mesh("tmp")
    up.bone("root")
    up.bone("body", "root", (0, 62, -6))
    joints = muscular_body(up, "body", s=1.0)
    armor_upper(up, joints)
    kusazuri(up, "torso", 74, 25, 11, 40)
    graft(m, up, "body", scale=S, offset=(0, lift - 54 * S, 0), skip=("root", "body"))
    # the crystal on the forehead: the user rides inside the head, looking out through it
    hx, hy, hz = 0, lift - 54 * S + 172 * S, -4 * S
    gem = V(hx, hy + 11 * S, hz + 21 * S)
    m.blob("head", "gem", gem, (12 * S, 11 * S, 6 * S), R=rot(0, 0, 0), e=(1, 1), seg=(6, 2), flat=True)
    bezel = [gem + V(7.2 * S * math.sin(math.radians(a)), 6.6 * S * math.cos(math.radians(a)), -1.2 * S) for a in range(0, 361, 30)]
    m.sweep("head", "trim", bezel, (1.8 * S, 1.8 * S), cap0=None, cap1=None, n=2, profile=circle(8))
    for sx, name in ((-1, "r"), (1, "l")):                                                                   # legs
        hip = V(sx * 15, lift, -2)
        knee = V(sx * 19, lift - 42, 6)
        ankle = V(sx * 21, 9, -2)
        leg = m.bone(f"leg_{name}", "hips", hip)
        limb(m, leg, hip + V(0, 4, 0), knee, 25, 17, bulge=0.12, bulge_at=0.35)
        plate(m, leg, "armor", (sx * 17, lift - 17, 11.5), (23, 31, 5), R=rot(-8, 0, sx * 6), e=(0.35, 0.7))       # thigh guard
        plate(m, leg, "armor", (sx * 28.5, lift - 18, 2), (5, 31, 22), R=rot(0, 0, sx * 6), e=(0.35, 0.7))
        shin = m.bone(f"shin_{name}", leg, knee)
        limb(m, shin, knee, ankle, 17, 12, bulge=0.25, bulge_at=0.28)
        m.blob(shin, "trim", knee + V(0, 0, 7.5), (19, 15, 9), e=(0.8, 0.9), seg=(16, 10))                       # knee cop
        mid = lerp(knee, ankle, 0.5)
        m.blob(shin, "armor", (sx * 20, mid[1] + 2, 3.5), (22, 36, 16), e=(0.45, 0.85), seg=(20, 12))            # greave
        m.sweep(shin, "trim", [V(sx * 20, ankle[1] + 9, -5) + V(-sx * 11, 0, 0), V(sx * 20, ankle[1] + 9, 12),
                               V(sx * 20, ankle[1] + 9, -5) + V(sx * 11, 0, 0)], (3, 3), n=4, profile=circle(8))
        foot = m.bone(f"foot_{name}", shin, ankle)
        m.blob(foot, "armor", (ankle[0], 5.5, 5), (21, 11, 31), e=(0.5, 0.8), v_range=(-60, 90), seg=(20, 10))
        m.blob(foot, "trim", (ankle[0], 4, 19.5), (16, 7, 7), e=(0.7, 0.8), seg=(14, 8))
    kusazuri(m, "hips", lift + 6, 26, 12, 38, s=1.1)
    m.meta = {"joints": joints, "scale": S, "offset": (0, lift - 54 * S, 0), "head": (0, 172, -4)}
    wy = lift - 54 * S + 138 * S
    for sx, name in ((-1, "r"), (1, "l")):
        w = m.bone(f"wing_{name}", "body", (sx * 16, wy, -26 * S - 4))
        wing(m, w, (sx * 16, wy, -26 * S - 4), sx, 1.15, feathers=12)
    return m


STAGES = [stage1, stage2, stage3, stage4, stage5]
