Voice lines for jutsu go in this folder, one mono OGG Vorbis file per jutsu, named after the jutsu's id:

  <jutsu id>.ogg        e.g. majestic_destroyer_flame.ogg, fireball.ogg, rasengan.ogg, water_shark.ogg
  eye_<technique>.ogg   e.g. eye_amaterasu.ogg, eye_tsukuyomi.ogg, eye_kamui.ogg

The full list of names is in the README ("Jutsu voice lines"). A file plays from the caster every time that jutsu goes
off; jutsu without a file stay silent (the game logs one "missing sound" line for each at startup, which is harmless).
Some jutsu share a file: all three Wood Release jutsu play mokuton.ogg, both clone jutsu play shadow_clone.ogg, and Kamui
and its snap both play eye_kamui.ogg (change the entries in assets/shinobiarts/sounds.json to split them).
Outside this folder: sharingan_on.ogg (every Sharingan activation and evolution), mangekyou_off.ogg (the eyes turning
off after a Mangekyou) and clone_poof.ogg (shadow clones vanishing).
Files must be mono to be heard from where the caster stands (stereo files play at full volume everywhere).
