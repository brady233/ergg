package com.shinobiarts.item;

import com.shinobiarts.ninja.EightGates;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * The Eight Inner Gates, held like a release: right-click opens the next gate (at the eighth, right-click is Night Guy);
 * Sneak + right-click closes them all. Given once a ninja has the Taijutsu for the first gate.
 */
public class EightGatesItem extends Item {
    public EightGatesItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer sp) {
            NinjaData d = NinjaData.get(sp);
            if (d != null) {
                if (sp.isShiftKeyDown()) EightGates.key(sp, d, true);
                else if (d.getGatesOpen() >= 8) EightGates.rightClick(sp, d);
                else EightGates.key(sp, d, false);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.eight_gates").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.shinobiarts.eight_gates_2").withStyle(ChatFormatting.GRAY));
    }
}
