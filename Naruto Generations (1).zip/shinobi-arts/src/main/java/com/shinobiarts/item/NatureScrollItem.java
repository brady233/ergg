package com.shinobiarts.item;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Trains an additional chakra nature, unlocking that release's jutsu scrolls. */
public class NatureScrollItem extends Item {
    private final ChakraNature nature;

    public NatureScrollItem(ChakraNature nature, Properties properties) {
        super(properties);
        this.nature = nature;
    }

    public ChakraNature getNature() {
        return nature;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        NinjaData data = NinjaData.get(sp);
        if (data == null) return InteractionResultHolder.pass(stack);

        if (!data.isAffinityRevealed()) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.need_affinity").withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }
        if (data.hasNature(nature)) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.already_have_nature", nature.displayName()).withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }

        data.unlockNature(nature);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        sp.sendSystemMessage(Component.translatable("message.shinobiarts.nature_unlocked", nature.displayName()).withStyle(ChatFormatting.GREEN));
        ReleaseItem.give(sp, nature);
        sp.serverLevel().sendParticles(ParticleTypes.ENCHANT, sp.getX(), sp.getY() + 1.2, sp.getZ(), 60, 0.5, 0.6, 0.5, 0.6);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_LEVELUP, sp.getSoundSource(), 1.0f, 0.8f);
        ModNetwork.sync(sp);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.nature_scroll", nature.displayName()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.shinobiarts.nature_scroll_req").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
