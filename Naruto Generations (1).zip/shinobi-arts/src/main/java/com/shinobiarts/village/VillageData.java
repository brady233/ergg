package com.shinobiarts.village;

import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Per-village data saved with the world: the quests each Kage has posted, the village storage where every
 * handed-in quest item ends up (54 slots, opened from the Kage menu), and the village's Advisors (kept here so
 * the quest board can list them while they're offline).
 */
public final class VillageData extends SavedData {
    public static final int STORAGE_SIZE = 54;
    private static final String DATA_NAME = "shinobiarts_villages";

    public static final class KageQuest {
        public final int id;
        public final String item;
        public final int count;
        public final int bottles;
        public final long ryo;
        public final String postedBy;

        public KageQuest(int id, String item, int count, int bottles, long ryo, String postedBy) {
            this.id = id;
            this.item = item;
            this.count = count;
            this.bottles = bottles;
            this.ryo = ryo;
            this.postedBy = postedBy;
        }
    }

    private final Map<String, List<KageQuest>> quests = new HashMap<>();
    private final Map<String, NonNullList<ItemStack>> storage = new HashMap<>();
    private final Map<String, Map<java.util.UUID, String>> advisors = new HashMap<>();
    /** When each village's Kage last posted a quest (real time, ms): one quest per kageQuestCooldownMinutes. */
    private final Map<String, Long> lastPost = new HashMap<>();
    private int nextId = 1;

    public static VillageData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(VillageData::load, VillageData::new, DATA_NAME);
    }

    public List<KageQuest> quests(String village) {
        return quests.computeIfAbsent(village, k -> new ArrayList<>());
    }

    public KageQuest quest(String village, int id) {
        for (KageQuest q : quests(village)) {
            if (q.id == id) return q;
        }
        return null;
    }

    public KageQuest post(String village, String item, int count, int bottles, long ryo, String postedBy) {
        KageQuest q = new KageQuest(nextId++, item, count, bottles, ryo, postedBy);
        quests(village).add(q);
        setDirty();
        return q;
    }

    /** Milliseconds until the village's Kage may post another quest (0 = now). */
    public long postCooldownLeft(String village, long nowMs) {
        long wait = com.shinobiarts.Config.i(com.shinobiarts.Config.KAGE_QUEST_COOLDOWN) * 60_000L;
        return Math.max(0L, lastPost.getOrDefault(village, 0L) + wait - nowMs);
    }

    public void markPosted(String village, long nowMs) {
        lastPost.put(village, nowMs);
        setDirty();
    }

    public boolean remove(String village, int id) {
        boolean removed = quests(village).removeIf(q -> q.id == id);
        if (removed) setDirty();
        return removed;
    }

    /** The village's Advisors (player id -> name), in the order they were appointed. */
    public Map<java.util.UUID, String> advisors(String village) {
        return advisors.computeIfAbsent(village, k -> new java.util.LinkedHashMap<>());
    }

    /** Records a player as an Advisor of {@code village} ("" = of none), removing them from every other village. */
    public void updateAdvisor(java.util.UUID id, String name, String village) {
        boolean changed = false;
        for (Map.Entry<String, Map<java.util.UUID, String>> e : advisors.entrySet()) {
            if (!e.getKey().equals(village) && e.getValue().remove(id) != null) changed = true;
        }
        if (!village.isEmpty()) {
            String old = advisors(village).put(id, name);
            if (!name.equals(old)) changed = true;
        }
        if (changed) setDirty();
    }

    public NonNullList<ItemStack> storage(String village) {
        return storage.computeIfAbsent(village, k -> NonNullList.withSize(STORAGE_SIZE, ItemStack.EMPTY));
    }

    /** Puts items into the village storage. Returns false (and changes nothing) if they don't all fit. */
    public boolean store(String village, List<ItemStack> items) {
        NonNullList<ItemStack> slots = storage(village);
        NonNullList<ItemStack> copy = NonNullList.withSize(STORAGE_SIZE, ItemStack.EMPTY);
        for (int i = 0; i < STORAGE_SIZE; i++) copy.set(i, slots.get(i).copy());
        for (ItemStack stack : items) {
            ItemStack rest = stack.copy();
            for (int i = 0; i < STORAGE_SIZE && !rest.isEmpty(); i++) {
                ItemStack s = copy.get(i);
                if (s.isEmpty()) {
                    copy.set(i, rest.copy());
                    rest.setCount(0);
                } else if (ItemStack.isSameItemSameTags(s, rest) && s.getCount() < s.getMaxStackSize()) {
                    int n = Math.min(rest.getCount(), s.getMaxStackSize() - s.getCount());
                    s.grow(n);
                    rest.shrink(n);
                }
            }
            if (!rest.isEmpty()) return false;
        }
        for (int i = 0; i < STORAGE_SIZE; i++) slots.set(i, copy.get(i));
        setDirty();
        return true;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("NextId", nextId);
        CompoundTag villages = new CompoundTag();
        for (String v : allVillages()) {
            CompoundTag vt = new CompoundTag();
            ListTag qs = new ListTag();
            for (KageQuest q : quests(v)) {
                CompoundTag qt = new CompoundTag();
                qt.putInt("Id", q.id);
                qt.putString("Item", q.item);
                qt.putInt("Count", q.count);
                qt.putInt("Bottles", q.bottles);
                qt.putLong("Ryo", q.ryo);
                qt.putString("By", q.postedBy);
                qs.add(qt);
            }
            vt.put("Quests", qs);
            ListTag items = new ListTag();
            NonNullList<ItemStack> slots = storage(v);
            for (int i = 0; i < STORAGE_SIZE; i++) {
                if (slots.get(i).isEmpty()) continue;
                CompoundTag it = new CompoundTag();
                it.putByte("Slot", (byte) i);
                slots.get(i).save(it);
                items.add(it);
            }
            vt.put("Storage", items);
            ListTag adv = new ListTag();
            advisors(v).forEach((id, name) -> {
                CompoundTag a = new CompoundTag();
                a.putUUID("Id", id);
                a.putString("Name", name);
                adv.add(a);
            });
            vt.put("Advisors", adv);
            if (lastPost.containsKey(v)) vt.putLong("LastPost", lastPost.get(v));
            villages.put(v, vt);
        }
        tag.put("Villages", villages);
        return tag;
    }

    private java.util.Set<String> allVillages() {
        java.util.Set<String> all = new java.util.HashSet<>(quests.keySet());
        all.addAll(storage.keySet());
        all.addAll(advisors.keySet());
        all.addAll(lastPost.keySet());
        return all;
    }

    private static VillageData load(CompoundTag tag) {
        VillageData data = new VillageData();
        data.nextId = Math.max(1, tag.getInt("NextId"));
        CompoundTag villages = tag.getCompound("Villages");
        for (String v : villages.getAllKeys()) {
            CompoundTag vt = villages.getCompound(v);
            for (Tag t : vt.getList("Quests", Tag.TAG_COMPOUND)) {
                CompoundTag qt = (CompoundTag) t;
                data.quests(v).add(new KageQuest(qt.getInt("Id"), qt.getString("Item"), qt.getInt("Count"), qt.getInt("Bottles"),
                        qt.getLong("Ryo"), qt.getString("By")));
            }
            NonNullList<ItemStack> slots = data.storage(v);
            for (Tag t : vt.getList("Storage", Tag.TAG_COMPOUND)) {
                CompoundTag it = (CompoundTag) t;
                int slot = it.getByte("Slot") & 255;
                if (slot < STORAGE_SIZE) slots.set(slot, ItemStack.of(it));
            }
            for (Tag t : vt.getList("Advisors", Tag.TAG_COMPOUND)) {
                CompoundTag a = (CompoundTag) t;
                if (a.hasUUID("Id")) data.advisors(v).put(a.getUUID("Id"), a.getString("Name"));
            }
            if (vt.contains("LastPost")) data.lastPost.put(v, vt.getLong("LastPost"));
        }
        return data;
    }
}
