package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.world.KamuiPillarsFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** World generation features (used by the mod's own dimensions, see data/shinobiarts/worldgen). */
public final class ModFeatures {
    private ModFeatures() {}

    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, ShinobiArts.MODID);

    public static final RegistryObject<KamuiPillarsFeature> KAMUI_PILLARS = FEATURES.register("kamui_pillars",
            () -> new KamuiPillarsFeature(NoneFeatureConfiguration.CODEC));
}
