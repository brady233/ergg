package com.shinobiarts.network;

import com.shinobiarts.item.BlankScrollItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: what the player wrote on the blank scroll in {@code hand} (the scroll writing screen). */
public class ScrollWritePacket {
    private final boolean offhand;
    private final String title, text;

    public ScrollWritePacket(InteractionHand hand, String title, String text) {
        this.offhand = hand == InteractionHand.OFF_HAND;
        this.title = title;
        this.text = text;
    }

    public ScrollWritePacket(FriendlyByteBuf buf) {
        this.offhand = buf.readBoolean();
        this.title = buf.readUtf(BlankScrollItem.MAX_TITLE);
        this.text = buf.readUtf(BlankScrollItem.MAX_TEXT);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(offhand);
        buf.writeUtf(title, BlankScrollItem.MAX_TITLE);
        buf.writeUtf(text, BlankScrollItem.MAX_TEXT);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null) return;
        ItemStack stack = player.getItemInHand(offhand ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (!(stack.getItem() instanceof BlankScrollItem)) return;
        BlankScrollItem.write(stack, title, text, player.getGameProfile().getName());
    }
}
