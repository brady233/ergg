package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Small triangle meshes for jutsu (assets/shinobiarts/meshes/*.bin, written by tools/make_jutsu_models.py): the
 * Rasengan's shells and the Rising Spikes cluster. Read on first use; a resource reload drops them.
 */
public final class JutsuMesh {
    /** One textured part: {@code data} holds 3 corners per triangle, each x y z u v nx ny nz. */
    public record Group(int texture, float opacity, int triangles, float[] data) {}

    private static final Map<String, List<Group>> CACHE = new HashMap<>();

    private JutsuMesh() {}

    public static synchronized List<Group> get(String name) {
        List<Group> mesh = CACHE.get(name);
        if (mesh != null) return mesh;
        mesh = new ArrayList<>();
        try {
            Optional<Resource> res = Minecraft.getInstance().getResourceManager()
                    .getResource(new ResourceLocation(ShinobiArts.MODID, "meshes/" + name + ".bin"));
            if (res.isEmpty()) throw new IOException("missing meshes/" + name + ".bin");
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(res.get().open()))) {
                int groups = in.readInt();
                for (int g = 0; g < groups; g++) {
                    int texture = in.readInt();
                    float opacity = in.readFloat();
                    int tris = in.readInt();
                    float[] data = new float[tris * 24];
                    for (int i = 0; i < data.length; i++) data[i] = in.readFloat();
                    mesh.add(new Group(texture, opacity, tris, data));
                }
            }
        } catch (IOException e) {
            ShinobiArts.LOGGER.error("Couldn't load the {} mesh", name, e);
        }
        CACHE.put(name, mesh);
        return mesh;
    }

    public static synchronized void clear() {
        CACHE.clear();
    }

    /** Draws a group (entity render types take quads, so each triangle is sent as a quad with its last corner twice). */
    public static void draw(Group group, PoseStack.Pose pose, VertexConsumer vc, float r, float g, float b, float a, int light, int overlay) {
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float[] d = group.data();
        for (int t = 0; t < group.triangles(); t++) {
            int base = t * 24;
            for (int k = 0; k < 4; k++) {
                int i = base + Math.min(k, 2) * 8;
                vc.vertex(m, d[i], d[i + 1], d[i + 2]).color(r, g, b, a).uv(d[i + 3], d[i + 4]).overlayCoords(overlay).uv2(light)
                        .normal(n, d[i + 5], d[i + 6], d[i + 7]).endVertex();
            }
        }
    }
}
