package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * Great Fire Annihilation: a sea of fire. From the caster's mouth a flood of flame pours out over the ground and spreads
 * in a huge fan, a towering crest of fire rolling along its front and the ground behind it left burning, until the whole
 * field is ablaze; then it dies down. (a = where it starts, b = a point the way it goes, size = how far it reaches.)
 */
final class FxFireSea {
    private FxFireSea() {}

    private static final ResourceLocation TONGUES = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/flame_tongues.png");
    /** Half the fan's width, in degrees. */
    static final float HALF_ANGLE = 70f;
    /** How fast the front rolls out (blocks per tick), and how long the field burns after it stops. */
    static final float SPEED = 1.1f;

    static void sea(FxClient.Ctx c) {
        Vec3 from = c.fx().a;
        Vec3 dir = c.fx().b.subtract(from);
        dir = new Vec3(dir.x, 0, dir.z);
        dir = dir.lengthSqr() < 1e-6 ? new Vec3(0, 0, 1) : dir.normalize();
        float reach = c.fx().size;
        float age = c.age();
        float spread = reach / SPEED;                                 // ticks for the front to get all the way out
        float front = Math.min(reach, age * SPEED);
        float dying = Mth.clamp((age - spread) / Math.max(1f, c.fx().ticks - spread), 0f, 1f);
        float base = Mth.clamp(age / 3f, 0f, 1f) * (1f - dying * dying);
        if (base <= 0.01f) return;
        double yaw0 = Math.atan2(dir.z, dir.x);
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(TONGUES));
        RandomSource r = FxDraw.rng(c.fx().seed, 3);
        int flames = 520;
        for (int k = 0; k < flames; k++) {
            double ang = yaw0 + Math.toRadians((r.nextFloat() * 2 - 1) * HALF_ANGLE);
            float dist = (float) Math.sqrt(r.nextFloat()) * reach;    // even over the area
            float col = r.nextInt(4);
            float flick = r.nextFloat() * 6.28f;
            float sizeRnd = 0.7f + r.nextFloat() * 0.6f;
            if (dist > front) continue;
            // tallest at the rolling crest, lower in the burning field behind it
            float behind = front - dist;
            float crest = (age < spread) ? Math.max(0f, 1f - behind / 4f) : 0f;
            float h = (1.3f + 2.8f * crest) * sizeRnd * (1f + 0.12f * Mth.sin(age * 0.9f + flick));
            h *= base;
            float w = h * 0.55f + 0.4f;
            Vec3 at = new Vec3(from.x + Math.cos(ang) * dist, from.y, from.z + Math.sin(ang) * dist);
            double gy = FxDraw.groundY(at.add(0, 2, 0));
            Vec3 p = new Vec3(at.x, gy + h * 0.45, at.z);
            float u0 = col / 4f;
            FxDraw.Paint paint = new FxDraw.Paint(u0, 0f, u0 + 0.25f, 1f, 255, 255, 255, Math.round(235 * Math.min(1f, base * 1.2f)));
            FxDraw.billboard(vc, c.ps(), c.camera(), p, w, h, 0f, paint, FxDraw.FULL);
        }
    }
}
