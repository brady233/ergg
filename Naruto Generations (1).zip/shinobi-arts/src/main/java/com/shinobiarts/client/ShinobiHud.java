package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

import java.util.ArrayList;
import java.util.List;

/**
 * The main HUD, drawn just left of the hotbar (leaving room for the off-hand slot):
 * health as numbers, Ryo, the blue chakra bar, the green Senjutsu bar, and the jutsu slots of the
 * release you're holding with a selection arrow and cooldown overlays. Above the scroll: your eyes (Sharingan
 * stage or Byakugan, lit while active) and the armor you're wearing. Shrinks on narrow screens.
 */
public final class ShinobiHud {
    // Content box (the jutsu panel), drawn on the beige paper of a scroll.
    private static final int W = 132;
    private static final int H = 54;
    /** The whole scroll: rolled end on the left, paper with red bands on the right (textures/gui/hud_scroll.png). */
    private static final ResourceLocation SCROLL = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/hud_scroll.png");
    private static final int SCROLL_TEX_W = 512, SCROLL_TEX_H = 442, SCROLL_ROLL_U = 86, SCROLL_EDGE_U = 500;
    private static final int FRAME_H = 80;
    private static final int FRAME_ROLL = Math.round(FRAME_H * SCROLL_ROLL_U / (float) SCROLL_TEX_H);
    private static final int CONTENT_X = FRAME_ROLL + 2, CONTENT_Y = 11;
    private static final int FRAME_W = CONTENT_X + W + 4;
    private static final int INK = 0xFF2E2014, INK_SOFT = 0xFF6A5640;
    private static final int SLOT = 13;
    private static final int SLOT_GAP = 2;
    private static final int MAX_VISIBLE_SLOTS = 7;

    private static final int CHAKRA_COLOR = 0xFF2F8CFF;
    private static final int CHAKRA_CHARGE_COLOR = 0xFF8FE8FF;
    private static final int SENJUTSU_COLOR = 0xFF3FBF4A;
    private static final int SAGE_COLOR = 0xFFF0A02A;

    /** The chakra figure drawn left of the chakra and Senjutsu bars (111 x 128 texture). */
    private static final ResourceLocation FIGURE = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/chakra_figure.png");
    private static final int FIGURE_W = 15, FIGURE_H = 17;
    private static final int BAR_X = 4 + FIGURE_W;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    /** The row of slots above the scroll: eyes, then helmet, chestplate, leggings and boots, then the eye techniques. */
    private static final int LOADOUT_SLOT = 18, LOADOUT_Y = -LOADOUT_SLOT - 3;
    private static final ResourceLocation[] SHARINGAN_ICONS = new ResourceLocation[4];
    private static final ResourceLocation BYAKUGAN_ICON = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/byakugan_icon.png");
    private static final net.minecraft.world.entity.EquipmentSlot[] ARMOR = {net.minecraft.world.entity.EquipmentSlot.HEAD,
            net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET};
    private static final ResourceLocation[] EMPTY_ARMOR = {net.minecraft.world.inventory.InventoryMenu.EMPTY_ARMOR_SLOT_HELMET,
            net.minecraft.world.inventory.InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE, net.minecraft.world.inventory.InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS,
            net.minecraft.world.inventory.InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS};

    /** The Mangekyou in each pattern (Itachi's is sharingan_icon_4). */
    private static final ResourceLocation[] MANGEKYOU_ICONS = new ResourceLocation[com.shinobiarts.ninja.MangekyouDesign.values().length];

    static {
        for (int i = 0; i < 4; i++) {
            SHARINGAN_ICONS[i] = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/sharingan_icon_" + (i + 1) + ".png");
        }
        for (com.shinobiarts.ninja.MangekyouDesign design : com.shinobiarts.ninja.MangekyouDesign.values()) {
            MANGEKYOU_ICONS[design.ordinal()] = design == com.shinobiarts.ninja.MangekyouDesign.ITACHI ? SHARINGAN_ICONS[3]
                    : new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/mangekyou_icon_" + design.id() + ".png");
        }
    }

    /** The icon of a Sharingan stage (the Mangekyou in its pattern). */
    public static ResourceLocation sharinganIcon(int stage, com.shinobiarts.ninja.MangekyouDesign design) {
        int s = Mth.clamp(stage, 1, 4);
        return s == 4 ? MANGEKYOU_ICONS[design.ordinal()] : SHARINGAN_ICONS[s - 1];
    }

    // Smoothly animated bar values.
    private static float shownChakra = -1;
    private static float shownSenjutsu = -1;
    private static long lastFrame;

    private ShinobiHud() {}

    public static void reset() {
        shownChakra = -1;
        shownSenjutsu = -1;
    }

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.options.hideGui || player == null || mc.level == null || player.isSpectator()) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        long now = mc.level.getGameTime();

        drawTints(g, d, width, height);
        animate(d);

        // Sit to the left of the hotbar and the off-hand slot.
        int right = width / 2 - 91 - 32;
        float scale = Mth.clamp((right - 4) / (float) FRAME_W, 0.5f, 1.0f);
        float left = right - FRAME_W * scale;
        float top = height - 2 - FRAME_H * scale;

        g.pose().pushPose();
        g.pose().translate(left, top, 0);
        g.pose().scale(scale, scale, 1f);
        drawScroll(g);
        drawLoadout(g, mc.font, player, d);
        g.pose().translate(CONTENT_X, CONTENT_Y, 0);
        drawPanel(g, mc.font, player, d, now);
        g.pose().popPose();
    }

    /** The scroll background, sliced so the rolled end keeps its shape and only the paper stretches. */
    private static void drawScroll(GuiGraphics g) {
        RenderSystem.enableBlend();
        int edge = Math.max(1, Math.round(FRAME_H * (SCROLL_TEX_W - SCROLL_EDGE_U) / (float) SCROLL_TEX_H));
        g.blit(SCROLL, FRAME_ROLL, 0, FRAME_W - FRAME_ROLL - edge, FRAME_H, SCROLL_ROLL_U, 0,
                SCROLL_EDGE_U - SCROLL_ROLL_U, SCROLL_TEX_H, SCROLL_TEX_W, SCROLL_TEX_H);
        g.blit(SCROLL, FRAME_W - edge, 0, edge, FRAME_H, SCROLL_EDGE_U, 0, SCROLL_TEX_W - SCROLL_EDGE_U, SCROLL_TEX_H,
                SCROLL_TEX_W, SCROLL_TEX_H);
        g.blit(SCROLL, 0, 0, FRAME_ROLL, FRAME_H, 0, 0, SCROLL_ROLL_U, SCROLL_TEX_H, SCROLL_TEX_W, SCROLL_TEX_H);
    }

    /**
     * Above the scroll: the eyes you have (the Sharingan at its stage, or the Byakugan; bright with a coloured
     * frame while active, faded while off) and your four armor pieces with their durability bars.
     */
    private static void drawLoadout(GuiGraphics g, Font font, LocalPlayer player, NinjaData d) {
        int x = CONTENT_X, y = LOADOUT_Y;
        com.shinobiarts.ninja.Dojutsu eye = d.getActiveDojutsu();
        if (eye == com.shinobiarts.ninja.Dojutsu.NONE && !d.availableDojutsu().isEmpty()) eye = d.availableDojutsu().get(0);
        if (eye != com.shinobiarts.ninja.Dojutsu.NONE) {
            boolean on = d.getActiveDojutsu() == eye;
            boolean sharingan = eye == com.shinobiarts.ninja.Dojutsu.SHARINGAN;
            slot(g, x, y, !on ? 0xFF4A4A55 : sharingan ? 0xFFE02828 : 0xFFC8B8F0);
            ResourceLocation icon = sharingan ? sharinganIcon(d.activeSharinganStage(), d.getMangekyouDesign()) : BYAKUGAN_ICON;
            RenderSystem.enableBlend();
            if (!on) RenderSystem.setShaderColor(1f, 1f, 1f, 0.45f);
            g.blit(icon, x + 1, y + 1, 16, 16, 0, 0, 64, 64, 64, 64);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            x += LOADOUT_SLOT + 3;
        }
        for (int i = 0; i < ARMOR.length; i++) {
            slot(g, x, y, 0xFF4A4A55);
            ItemStack stack = player.getItemBySlot(ARMOR[i]);
            if (stack.isEmpty()) {
                net.minecraft.client.renderer.texture.TextureAtlasSprite sprite = Minecraft.getInstance()
                        .getTextureAtlas(net.minecraft.world.inventory.InventoryMenu.BLOCK_ATLAS).apply(EMPTY_ARMOR[i]);
                RenderSystem.enableBlend();
                RenderSystem.setShaderColor(1f, 1f, 1f, 0.35f);
                g.blit(x + 1, y + 1, 0, 16, 16, sprite);
                RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            } else {
                g.renderItem(stack, x + 1, y + 1);
                g.renderItemDecorations(font, stack, x + 1, y + 1);
            }
            x += LOADOUT_SLOT - 1;  // armor slots share their edges, like an inventory row
        }
        drawEyeTechniques(g, font, player, d, x + 4);
    }

    /**
     * After the armor: the eye techniques on the Jutsu keys (Amaterasu, Kamui, Genjutsu...), with the key in the
     * corner and a cooldown that drains from the top. Faded while the eyes are off. While sneaking, Jutsu 2 shows the
     * sneak version (Kamui snap, black flame wall). With the Byakugan on, its own three techniques.
     */
    private static void drawEyeTechniques(GuiGraphics g, Font font, LocalPlayer player, NinjaData d, int x) {
        if (d.getSharinganStage() <= 0 && !com.shinobiarts.ninja.EyeTechniques.usesByakugan(d)) return;
        long now = player.level().getGameTime();
        for (int key = 1; key <= 3; key++) {
            com.shinobiarts.ninja.EyeTechniques.Technique t = com.shinobiarts.ninja.EyeTechniques.technique(d, key, player.isShiftKeyDown());
            if (t == null) continue;
            boolean on = com.shinobiarts.ninja.EyeTechniques.eyesOn(d, t);
            boolean active = (t == com.shinobiarts.ninja.EyeTechniques.Technique.KAMUI && d.isIntangible(now))
                    || (t == com.shinobiarts.ninja.EyeTechniques.Technique.ALL_SEEING && d.getAllSeeingUntil() > now);
            int frame = t.byakugan() ? 0xFFB7A8E8 : 0xFFB01818;
            slot(g, x, 0 + LOADOUT_Y, active ? 0xFFB070FF : on ? frame : 0xFF4A4A55);
            RenderSystem.enableBlend();
            if (!on) RenderSystem.setShaderColor(1f, 1f, 1f, 0.45f);
            g.blit(t.icon(), x + 1, LOADOUT_Y + 1, 16, 16, 0, 0, 64, 64, 64, 64);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            long remaining = d.cooldownRemaining(t.cooldownId(), now);
            if (remaining > 0) {
                long total = Math.max(1L, t.cooldownTicks());
                int h = Mth.clamp((int) Math.ceil(16 * (remaining / (float) total)), 1, 16);
                g.fill(x + 1, LOADOUT_Y + 1, x + 17, LOADOUT_Y + 1 + h, 0xB0000000);
                String secs = String.valueOf((remaining + 19) / 20);
                g.pose().pushPose();
                g.pose().translate(x + 9 - font.width(secs) * 0.6f / 2f, LOADOUT_Y + 6.5f, 0);
                g.pose().scale(0.6f, 0.6f, 1f);
                g.drawString(font, secs, 0, 0, 0xFFFFD34A, true);
                g.pose().popPose();
            }
            // the key it's on, in the bottom-right corner
            String keyName = KeyBinds.JUTSU_KEYS[key - 1].getTranslatedKeyMessage().getString();
            if (keyName.length() > 2) keyName = keyName.substring(0, 2);
            g.pose().pushPose();
            g.pose().translate(x + 17 - font.width(keyName) * 0.55f, LOADOUT_Y + 12.5f, 0);
            g.pose().scale(0.55f, 0.55f, 1f);
            g.drawString(font, keyName, 0, 0, 0xFFFFFFFF, true);
            g.pose().popPose();
            x += LOADOUT_SLOT + 2;
        }
    }

    /** A dark see-through slot with a 1px frame. */
    private static void slot(GuiGraphics g, int x, int y, int frame) {
        int s = LOADOUT_SLOT;
        g.fill(x + 1, y + 1, x + s - 1, y + s - 1, 0xA0101018);
        g.fill(x, y, x + s, y + 1, frame);
        g.fill(x, y + s - 1, x + s, y + s, frame);
        g.fill(x, y + 1, x + 1, y + s - 1, frame);
        g.fill(x + s - 1, y + 1, x + s, y + s - 1, frame);
    }

    private static void animate(NinjaData d) {
        long t = System.nanoTime();
        float dt = lastFrame == 0 ? 1f : Math.min(1f, (t - lastFrame) / 1.0e9f * 10f);
        lastFrame = t;
        if (shownChakra < 0) shownChakra = d.getChakra();
        if (shownSenjutsu < 0) shownSenjutsu = d.getSenjutsu();
        shownChakra += (d.getChakra() - shownChakra) * dt;
        shownSenjutsu += (d.getSenjutsu() - shownSenjutsu) * dt;
    }

    private static void drawTints(GuiGraphics g, NinjaData d, int width, int height) {
        int band = Math.max(20, height / 7);
        if (Minecraft.getInstance().level != null && d.isIntangible(Minecraft.getInstance().level.getGameTime())) {
            g.fillGradient(0, 0, width, band, 0x504A1A70, 0x00000000);   // Kamui: a purple haze
            g.fillGradient(0, height - band, width, height, 0x00000000, 0x504A1A70);
        } else if (d.isDojutsuActive()) {
            int tint = d.getActiveDojutsu() == com.shinobiarts.ninja.Dojutsu.SHARINGAN ? 0x50A00000 : 0x40C8DCFF;
            g.fillGradient(0, 0, width, band, tint, 0x00000000);
            g.fillGradient(0, height - band, width, height, 0x00000000, tint);
        } else if (d.isSageMode()) {
            g.fillGradient(0, 0, width, band, 0x30F0A02A, 0x00000000);
            g.fillGradient(0, height - band, width, height, 0x00000000, 0x30F0A02A);
        }
    }

    private static void drawPanel(GuiGraphics g, Font font, LocalPlayer player, NinjaData d, long now) {
        ChakraNature release = ReleaseItem.heldRelease(player);
        int accent = release != null ? 0xFF000000 | release.rgb() : 0xFF3A3A48;

        // Status tags above the panel.
        List<Component> tags = new ArrayList<>();
        if (d.isDojutsuActive()) tags.add(d.dojutsuName(d.getActiveDojutsu()));
        if (d.isSageMode()) tags.add(Component.translatable("hud.shinobiarts.sage"));
        if (d.isCharging()) tags.add(Component.translatable("hud.shinobiarts.charging"));
        if (d.getRasenganUntil() > now) tags.add(Component.translatable("hud.shinobiarts.rasengan"));
        if (d.isSubstitutionOn() && d.knows(com.shinobiarts.jutsu.Jutsus.SUBSTITUTION.id())) {
            boolean ready = d.cooldownRemaining(com.shinobiarts.jutsu.Jutsus.SUBSTITUTION.id(), now) == 0;
            tags.add(Component.translatable("hud.shinobiarts.substitution")
                    .withStyle(ready ? net.minecraft.ChatFormatting.LIGHT_PURPLE : net.minecraft.ChatFormatting.DARK_GRAY));
        }
        if (d.isChakraControl()) tags.add(Component.translatable("hud.shinobiarts.chakra_control").withStyle(net.minecraft.ChatFormatting.AQUA));
        if (d.getGatesOpen() > 0) {
            int gates = d.getGatesOpen();
            tags.add(Component.translatable("hud.shinobiarts.gates", gates).withStyle(gates >= 8 ? net.minecraft.ChatFormatting.RED
                    : gates >= 6 ? net.minecraft.ChatFormatting.GREEN : net.minecraft.ChatFormatting.AQUA));
        }
        if (d.isIntangible(now)) tags.add(Component.translatable("hud.shinobiarts.kamui"));
        if (d.getBoostTicks() > 0) {
            long left = d.getBoostTicks() - Math.max(0, now - ClientNinjaData.syncTime());
            if (left > 0) {
                long secs = left / 20;
                tags.add(Component.translatable("hud.shinobiarts.boost", com.shinobiarts.item.XpBoostItem.format(d.getBoostMultiplier()),
                        String.format("%d:%02d", secs / 60, secs % 60)).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
            }
        }
        if (!tags.isEmpty()) {
            Component line = Component.empty();
            for (int i = 0; i < tags.size(); i++) {
                if (i > 0) ((net.minecraft.network.chat.MutableComponent) line).append(Component.literal("  "));
                ((net.minecraft.network.chat.MutableComponent) line).append(tags.get(i));
            }
            smallText(g, font, line, 0, -CONTENT_Y + LOADOUT_Y - 9, 0.75f, 0xFFFFFF);
        }

        // Panel background with an accent line in the held release's colour.
        g.fill(0, H + 1, W, H + 2, (accent & 0x00FFFFFF) | 0x90000000); // held release's colour, just above the bottom band

        // Row 1: Ryo on the left (shortened: 1.2k, 15k, 250k, 1.5M), then the XP bar, then the level on the right.
        drawCoin(g, 2, 2);
        String ryo = PlayerDataManager.formatRyoShort(d.getRyo());
        g.drawString(font, ryo, 12, 3, 0xFF7A4E00, false);
        Component lvl = Component.literal("Lv " + d.getLevel());
        int lvlX = W - 3 - font.width(lvl);
        g.drawString(font, lvl, lvlX, 3, INK, false);
        drawXpBar(g, 12 + font.width(ryo) + 5, 5, lvlX - 4 - (12 + font.width(ryo) + 5), d);

        // Rows 2-3: the chakra figure, then the chakra bar and the Senjutsu bar (once you've invested in Senjutsu).
        RenderSystem.enableBlend();
        g.blit(FIGURE, 2, 12, FIGURE_W, FIGURE_H, 0, 0, 111, 128, 111, 128);
        drawBar(g, font, BAR_X, 14, W - BAR_X - 3, 7, shownChakra, d.getChakra(), d.maxChakra(),
                d.isCharging() ? CHAKRA_CHARGE_COLOR : CHAKRA_COLOR, now, d.isCharging());
        if (d.maxSenjutsu() > 0) {
            drawBar(g, font, BAR_X, 23, W - BAR_X - 3, 5, shownSenjutsu, d.getSenjutsu(), d.maxSenjutsu(),
                    d.isSageMode() ? SAGE_COLOR : SENJUTSU_COLOR, now, false);
        }

        // Rows 4-5: release icon, jutsu slots, selected jutsu.
        int slotY = 33;
        if (release == null) {
            // centred on the scroll, wrapped onto two lines if it doesn't fit
            inkCentered(g, font, Component.translatable("hud.shinobiarts.hold_release"), W / 2f, slotY + 2, W - 8, 0.75f, INK_SOFT);
            return;
        }
        RenderSystem.enableBlend();
        g.blit(release.icon(), 2, slotY - 1, 15, 15, 0, 0, 64, 64, 64, 64);
        List<Jutsu> slots = d.slots(release);
        if (!d.hasNature(release)) {
            inkCentered(g, font, Component.translatable("hud.shinobiarts.release_locked"), 19 + (W - 19) / 2f, slotY + 2, W - 23, 0.75f, 0xFFA01818);
            return;
        }
        if (slots.isEmpty()) {
            inkCentered(g, font, Component.translatable("hud.shinobiarts.release_empty"), 19 + (W - 19) / 2f, slotY + 2, W - 23, 0.75f, INK_SOFT);
            return;
        }
        int selected = d.getSelectedSlot(release);
        int first = Mth.clamp(selected - MAX_VISIBLE_SLOTS / 2, 0, Math.max(0, slots.size() - MAX_VISIBLE_SLOTS));
        int last = Math.min(slots.size(), first + MAX_VISIBLE_SLOTS);
        for (int i = first; i < last; i++) {
            int x = 20 + (i - first) * (SLOT + SLOT_GAP);
            drawSlot(g, font, slots.get(i), x, slotY, i == selected, release, d, now);
        }
        if (first > 0) inkText(g, font, Component.literal("<"), 17, slotY + 3, 0.7f, INK);
        if (last < slots.size()) inkText(g, font, Component.literal(">"), W - 4, slotY + 3, 0.7f, INK);

        Jutsu jutsu = slots.get(selected);
        long remaining = d.cooldownRemaining(jutsu.id(), now);
        Component status = remaining > 0
                ? Component.literal(String.format("  %.1fs", remaining / 20.0f)).withStyle(s -> s.withColor(0x6A5640))
                : (d.getChakra() >= jutsu.cost(d)
                    ? Component.translatable("hud.shinobiarts.ready").withStyle(s -> s.withColor(0x1E7A2E))
                    : Component.translatable("hud.shinobiarts.low_chakra").withStyle(s -> s.withColor(0xA01818)));
        Component name = Component.literal(shortName(jutsu)).withStyle(s -> s.withColor(0x2E2014))
                .append(Component.literal(" (" + (int) Math.ceil(jutsu.cost(d)) + ")").withStyle(s -> s.withColor(0x1F4F9F)))
                .append(status);
        inkText(g, font, name, 3, slotY + SLOT + 4, 0.75f, INK);
    }

    private static void drawSlot(GuiGraphics g, Font font, Jutsu jutsu, int x, int y, boolean selected,
                                 ChakraNature release, NinjaData d, long now) {
        int color = jutsu.clan() != null && release == ChakraNature.NONE ? 0xFF7A1F2B : 0xFF000000 | release.rgb();
        g.fill(x, y, x + SLOT, y + SLOT, 0xFF15151C);
        g.fill(x + 1, y + 1, x + SLOT - 1, y + SLOT - 1, (color & 0x00FFFFFF) | 0xA0000000);
        // two-letter abbreviation
        String abbr = abbreviation(jutsu);
        float s = 0.7f;
        g.pose().pushPose();
        g.pose().translate(x + SLOT / 2f - font.width(abbr) * s / 2f, y + SLOT / 2f - 3f, 0);
        g.pose().scale(s, s, 1f);
        g.drawString(font, abbr, 0, 0, 0xFFFFFFFF, true);
        g.pose().popPose();

        // cooldown overlay: darkens from the top, shrinking as it recharges
        long remaining = d.cooldownRemaining(jutsu.id(), now);
        if (remaining > 0) {
            long total = jutsu.cooldownFor(d);
            int h = Mth.clamp((int) Math.ceil(SLOT * (remaining / (float) total)), 1, SLOT);
            g.fill(x, y, x + SLOT, y + h, 0xB0000000);
            String secs = remaining >= 200 ? String.valueOf(remaining / 20) : String.format("%.0f", Math.ceil(remaining / 20.0));
            g.pose().pushPose();
            g.pose().translate(x + SLOT / 2f - font.width(secs) * 0.6f / 2f, y + SLOT / 2f - 2.5f, 0);
            g.pose().scale(0.6f, 0.6f, 1f);
            g.drawString(font, secs, 0, 0, 0xFFFFD34A, true);
            g.pose().popPose();
        }

        if (selected) {
            // white frame + arrow above
            g.fill(x - 1, y - 1, x + SLOT + 1, y, 0xFFFFFFFF);
            g.fill(x - 1, y + SLOT, x + SLOT + 1, y + SLOT + 1, 0xFFFFFFFF);
            g.fill(x - 1, y, x, y + SLOT, 0xFFFFFFFF);
            g.fill(x + SLOT, y, x + SLOT + 1, y + SLOT, 0xFFFFFFFF);
            int cx = x + SLOT / 2;
            g.fill(cx - 2, y - 4, cx + 3, y - 3, 0xFFFFFFFF);
            g.fill(cx - 1, y - 3, cx + 2, y - 2, 0xFFFFFFFF);
        }
    }

    /**
     * A soft, rounded bar: a faint glow in the bar's color, a dark see-through track, and a fill with rounded ends
     * that is lighter at the top and fades darker toward the bottom. Drawn at double resolution so the rounded
     * ends stay smooth.
     */
    private static void drawBar(GuiGraphics g, Font font, int x, int y, int w, int h, float shown, float actual, float max,
                                int color, long now, boolean shimmer) {
        float frac = max <= 0 ? 0 : Mth.clamp(shown / max, 0f, 1f);
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.5f, 0.5f, 1f);
        int bw = w * 2, bh = h * 2;

        // glow: a slightly larger pill in the bar's color, very transparent
        pill(g, -2, -2, bw + 4, bh + 4, (color & 0x00FFFFFF) | 0x26000000, 0, 0);
        pill(g, -1, -1, bw + 2, bh + 2, 0x80080810, 0, 0);
        // track
        pill(g, 0, 0, bw, bh, 0xB01A1A26, 0, 0);
        // fill
        int filled = Math.round(bw * frac);
        if (filled > 0) {
            int top = shade(color, 1.35f), bottom = shade(color, 0.62f);
            pill(g, 0, 0, filled, bh, color, top, bottom);
            // soft highlight across the upper third
            pill(g, 2, 1, filled - 4, Math.max(2, bh / 3), 0x30FFFFFF, 0, 0);
            if (shimmer) {
                int pos = (int) ((now * 8) % (bw + 24)) - 12;
                int s0 = Mth.clamp(pos, 0, filled), s1 = Mth.clamp(pos + 12, 0, filled);
                if (s1 > s0) g.fill(s0, 1, s1, bh - 1, 0x50FFFFFF);
            }
        }
        g.pose().popPose();

        if (h >= 6) {
            String text = (int) actual + "/" + (int) max;
            float s = 0.65f;
            g.pose().pushPose();
            g.pose().translate(x + w / 2f - font.width(text) * s / 2f, y + (h - 9 * s) / 2f + 0.5f, 0);
            g.pose().scale(s, s, 1f);
            g.drawString(font, text, 0, 0, 0xFFFFFFFF, true);
            g.pose().popPose();
        }
    }

    /**
     * A horizontal pill (rectangle with fully rounded ends), drawn one row at a time.
     * If top/bottom are non-zero the rows blend from the top color through `color` to the bottom color.
     */
    private static void pill(GuiGraphics g, int x, int y, int w, int h, int color, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        float r = Math.min(h, w) / 2f;
        for (int row = 0; row < h; row++) {
            float dy = row + 0.5f - h / 2f;
            float half = (float) Math.sqrt(Math.max(0f, r * r - dy * dy));
            int inset = Math.round(r - half);
            if (inset * 2 >= w) continue;
            int c = color;
            if (top != 0) {
                float t = h <= 1 ? 0f : row / (float) (h - 1);
                c = t < 0.5f ? lerpColor(top, color, t * 2f) : lerpColor(color, bottom, (t - 0.5f) * 2f);
            }
            g.fill(x + inset, y + row, x + w - inset, y + row + 1, c);
        }
    }

    private static int shade(int argb, float f) {
        int r = Math.min(255, Math.round(((argb >> 16) & 0xFF) * f));
        int gr = Math.min(255, Math.round(((argb >> 8) & 0xFF) * f));
        int b = Math.min(255, Math.round((argb & 0xFF) * f));
        return (argb & 0xFF000000) | (r << 16) | (gr << 8) | b;
    }

    private static int lerpColor(int a, int b, float t) {
        int out = 0;
        for (int shift = 0; shift <= 24; shift += 8) {
            int ca = (a >> shift) & 0xFF, cb = (b >> shift) & 0xFF;
            out |= Math.round(ca + (cb - ca) * t) << shift;
        }
        return out;
    }

    /**
     * The health bar that replaces the vanilla hearts, drawn where the hearts were (above the hotbar).
     * Shows current/max health as numbers, with absorption as a gold extension.
     */
    public static void drawHealthBar(GuiGraphics g, int x, int y, LocalPlayer player) {
        Font font = Minecraft.getInstance().font;
        int w = 81, h = 9;
        float max = Math.max(1f, player.getMaxHealth());
        float hp = Mth.clamp(player.getHealth(), 0f, max);
        float abs = player.getAbsorptionAmount();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF0B0B12);
        g.fill(x, y, x + w, y + h, 0xFF2A1416);
        int filled = Math.round(w * hp / max);
        boolean low = hp / max <= 0.25f;
        int color = low && (System.currentTimeMillis() / 300) % 2 == 0 ? 0xFFFF5A5A : 0xFFD8323A;
        g.fill(x, y, x + filled, y + h, color);
        g.fill(x, y, x + filled, y + 3, 0x40FFFFFF);
        if (abs > 0) {
            int absW = Math.min(w, Math.round(w * abs / max));
            g.fill(x, y + h - 2, x + absW, y + h, 0xFFFFD34A);
        }
        drawHeart(g, x + 2, y + 1);
        String text = (int) Math.ceil(hp) + " / " + (int) Math.ceil(max) + (abs > 0 ? "  +" + (int) Math.ceil(abs) : "");
        g.drawString(font, text, x + (w - font.width(text)) / 2 + 4, y + 1, 0xFFFFFFFF, true);
    }

    /** A tiny pixel heart. */
    private static void drawHeart(GuiGraphics g, int x, int y) {
        int red = 0xFFE03A3A, dark = 0xFF8A1C1C;
        g.fill(x + 1, y, x + 3, y + 1, red);
        g.fill(x + 4, y, x + 6, y + 1, red);
        g.fill(x, y + 1, x + 7, y + 4, red);
        g.fill(x + 1, y + 4, x + 6, y + 5, red);
        g.fill(x + 2, y + 5, x + 5, y + 6, dark);
        g.fill(x + 3, y + 6, x + 4, y + 7, dark);
        g.fill(x + 1, y + 1, x + 2, y + 2, 0xFFFFB0B0);
    }

    /** Draws the gold Ryo coin item at half size. */
    private static void drawCoin(GuiGraphics g, int x, int y) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.55f, 0.55f, 1f);
        g.renderItem(new ItemStack(ModItems.coin(CoinItem.Coin.GOLD)), 0, 0);
        g.pose().popPose();
    }

    /** Ink text centred on {@code cx}, wrapped to {@code maxWidth} (in panel pixels) so it never runs off the scroll. */
    private static void inkCentered(GuiGraphics g, Font font, Component text, float cx, float y, int maxWidth, float scale, int color) {
        List<net.minecraft.util.FormattedCharSequence> lines = font.split(text, Math.max(10, (int) (maxWidth / scale)));
        if (lines.size() == 1) y += 2;                              // a single line sits in the middle of the slot row
        for (net.minecraft.util.FormattedCharSequence line : lines) {
            g.pose().pushPose();
            g.pose().translate(cx - font.width(line) * scale / 2f, y, 0);
            g.pose().scale(scale, scale, 1f);
            g.drawString(font, line, 0, 0, color, false);
            g.pose().popPose();
            y += 9 * scale + 1;
        }
    }

    /** A thin XP bar before the level: how far the player is toward the next level (full at the rank's cap). */
    private static void drawXpBar(GuiGraphics g, int x, int y, int w, NinjaData d) {
        if (w < 8) return;
        float frac = d.isMaxLevel() ? 1f : Mth.clamp(d.getXp() / (float) Math.max(1, d.xpToNext()), 0f, 1f);
        g.fill(x - 1, y - 1, x + w + 1, y + 4, 0xFF8E7A5A);          // inked frame, like the scroll's paper
        g.fill(x, y, x + w, y + 3, 0xFFF1E6C8);
        int filled = Math.round(w * frac);
        if (filled > 0) {
            g.fill(x, y, x + filled, y + 3, d.isMaxLevel() ? 0xFFD9A21E : 0xFF6FBF4F);
            g.fill(x, y, x + filled, y + 1, 0x40FFFFFF);
        }
    }

    /** Small text without a shadow, for writing on the scroll's paper. */
    private static void inkText(GuiGraphics g, Font font, Component text, float x, float y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, color, false);
        g.pose().popPose();
    }

    private static void smallText(GuiGraphics g, Font font, Component text, float x, float y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, color, true);
        g.pose().popPose();
    }

    /** "Fire Release: Great Fireball" -> "Great Fireball". */
    static String shortName(Jutsu jutsu) {
        String full = jutsu.displayName().getString();
        int colon = full.indexOf(": ");
        return colon >= 0 ? full.substring(colon + 2) : full;
    }

    /** "Great Fireball" -> "GF", "Chidori" -> "Ch". */
    static String abbreviation(Jutsu jutsu) {
        String[] words = shortName(jutsu).trim().split("\\s+");
        if (words.length >= 2 && !words[0].isEmpty() && !words[1].isEmpty()) {
            return ("" + words[0].charAt(0) + words[words.length - 1].charAt(0)).toUpperCase();
        }
        String w = words[0];
        return w.length() >= 2 ? w.substring(0, 1).toUpperCase() + w.charAt(1) : w.toUpperCase();
    }
}
