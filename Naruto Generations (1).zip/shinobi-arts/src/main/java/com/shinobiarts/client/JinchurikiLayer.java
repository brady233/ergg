package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.TailedBeast;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * A jinchuriki's tailed beast chakra, on anyone in a form:
 * <ul>
 *   <li>Rage, 1 to 3 tails: a boiling, see-through shroud of the beast's chakra, glowing white eyes, its ears or horns
 *       and as many chakra tails as the form has.</li>
 *   <li>Rage, 4 to 6 tails: the shroud turns dark and thick (the beast's darker colour) with its own colour glowing
 *       through at the edges.</li>
 *   <li>Chakra cloak: a bright, burning cloak of the beast's colour with dark swirling markings, every one of its tails
 *       and eyes of its colour.</li>
 * </ul>
 */
public class JinchurikiLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation SHROUD = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jinchuriki/shroud.png");
    private static final ResourceLocation CLOAK = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jinchuriki/cloak.png");
    private final HumanoidModel<T> inner, outer;

    public JinchurikiLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.inner = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHROUD_INNER_LAYER));
        this.outer = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHROUD_OUTER_LAYER));
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                       float partial, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) return;
        int look = ClientEyes.look(entity);
        TailedBeast beast = TailedBeast.byTails(SharinganManager.lookBeast(look));
        int form = SharinganManager.lookBeastForm(look);
        if (beast == null || form == Jinchuriki.NONE) return;
        boolean cloak = form == Jinchuriki.CLOAK;
        boolean dark = !cloak && form >= 4;
        int tails = cloak ? beast.tails : Math.min(form, beast.tails);
        float t = ageInTicks;

        getParentModel().copyPropertiesTo(inner);
        getParentModel().copyPropertiesTo(outer);
        inner.setAllVisible(true);
        outer.setAllVisible(true);
        float[] c = rgb(beast.color), d = rgb(beast.dark);
        float pulse = 0.85f + 0.15f * Mth.sin(t * 0.3f);

        // the shroud itself
        if (cloak) {
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(CLOAK)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, lift(c[0]), lift(c[1]), lift(c[2]), 0.82f);
        } else if (dark) {
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(SHROUD)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, d[0], d[1], d[2], 0.93f);
        } else {
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(SHROUD)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, c[0], c[1], c[2], 0.55f);
        }
        // the chakra boiling off it
        float k = (dark ? 0.35f : cloak ? 0.45f : 0.6f) * pulse;
        VertexConsumer swirl = buffers.getBuffer(RenderType.energySwirl(SHROUD, (t * 0.011f) % 1f, (-t * 0.035f) % 1f));
        outer.renderToBuffer(ps, swirl, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, c[0] * k, c[1] * k, c[2] * k, 1f);

        VertexConsumer glow = FxDraw.glow(buffers);
        FxDraw.Paint body = dark ? FxDraw.color(beast.dark, 0.92f) : FxDraw.color(cloak ? brighten(beast.color) : beast.color, cloak ? 0.8f : 0.6f);
        FxDraw.Paint edge = FxDraw.color(beast.color, dark ? 0.35f : 0.25f);

        // the tails, from the small of the back
        ps.pushPose();
        getParentModel().body.translateAndRotate(ps);
        Vec3 root = new Vec3(0, 0.68, 0.16);
        for (int i = 0; i < tails; i++) {
            float fan = tails == 1 ? 0f : (i / (float) (tails - 1) - 0.5f) * Math.min(2.6f, 0.45f * tails);
            float phase = t * 0.12f + i * 1.7f;
            List<Vec3> pts = new ArrayList<>();
            int n = 10;
            float len = cloak ? 1.5f : 1.15f + 0.07f * tails;
            float[] radii = new float[n + 1], halo = new float[n + 1];
            float base = beast == TailedBeast.KURAMA ? 0.19f : 0.15f;
            for (int j = 0; j <= n; j++) {
                float s = j / (float) n;
                float wave = Mth.sin(phase + s * 3.2f) * 0.35f * s;
                float x = Mth.sin(fan) * len * s * 0.9f + wave * Mth.cos(fan);
                float z = Mth.cos(fan) * len * s * 0.8f + 0.2f * s;
                float y = -(len * 0.45f) * s * s - 0.35f * len * s * s * s * s + Mth.cos(phase * 0.8f + s * 2f) * 0.08f * s;
                pts.add(root.add(x, y, z));
                float r = base * (1 + 0.6f * Mth.sin(Mth.PI * Math.min(1f, s * 1.15f))) * (1 - 0.55f * s * s) + 0.03f;
                radii[j] = r;
                halo[j] = r * 1.4f + 0.02f;
            }
            FxDraw.tube(glow, ps, pts, radii, 8, body, 1f, LightTexture.FULL_BRIGHT, true);
            FxDraw.tube(glow, ps, pts, halo, 8, edge, 1f, LightTexture.FULL_BRIGHT, false);
        }
        ps.popPose();

        // the head: ears or horns, and the eyes
        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        head(glow, ps, beast.head, body, edge, t);
        FxDraw.Paint eye = cloak ? FxDraw.color(brighten(beast.color), 1f) : FxDraw.color(0xFFFFFF, 1f);
        float z = -0.312f;
        float open = blink(entity.getId(), t);
        if (open > 0.06f) {                                  // shut tight for a moment while it blinks
            for (int sx = -1; sx <= 1; sx += 2) {
                float x0 = sx * 0.06f, x1 = sx * 0.2f;
                float mi = -0.225f, mo = -0.27f;              // the eye closes onto its middle line
                FxDraw.quad(glow, ps, new Vec3(x0, mi + (-0.24f - mi) * open, z), new Vec3(x1, mo + (-0.29f - mo) * open, z),
                        new Vec3(x1, mo + (-0.25f - mo) * open, z), new Vec3(x0, mi + (-0.21f - mi) * open, z), eye, LightTexture.FULL_BRIGHT);
            }
        }
        ps.popPose();
    }

    /**
     * How open the shroud's eyes are (1 open, 0 shut): a blink at a random moment every three and a half seconds or
     * so, sometimes a quick double blink. Every player blinks on their own time.
     */
    private static float blink(int id, float t) {
        int cycle = 70;
        long k = (long) Math.floor(t / cycle);
        float in = t - k * cycle;
        int h = (int) (k * 73856093L) ^ (id * 19349663);
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        float start = 8f + ((h >>> 8) & 0xFFFF) / 65535f * 50f;
        float open = shut(in - start);
        if (((h >>> 3) & 3) == 0) open = Math.min(open, shut(in - start - 6f));
        return open;
    }

    /** One blink, {@code d} ticks after it starts: two ticks closing, a tick shut, two ticks opening. */
    private static float shut(float d) {
        if (d < 0 || d > 5) return 1f;
        if (d < 2) return 1f - d / 2f;
        if (d < 3) return 0f;
        return (d - 3f) / 2f;
    }

    /** What grows on the shroud's head (head space: blocks, y down, the face toward -z). */
    private static void head(VertexConsumer vc, PoseStack ps, TailedBeast.HeadShape head, FxDraw.Paint p, FxDraw.Paint edge, float t) {
        int L = LightTexture.FULL_BRIGHT;
        float sway = Mth.sin(t * 0.1f) * 0.02f;
        for (int sx = -1; sx <= 1; sx += 2) {
            switch (head) {
                case ROUND_EARS -> FxDraw.sphere(vc, ps, new Vec3(sx * 0.23, -0.6, 0.02), 0.11f, 6, 8, p, L);
                case CAT_EARS -> FxDraw.cone(vc, ps, new Vec3(sx * 0.17, -0.5, 0), new Vec3(sx * 0.27 + sway, -0.82, 0.03), 0.1f, 8, p, L);
                case FOX_EARS -> {
                    FxDraw.cone(vc, ps, new Vec3(sx * 0.16, -0.5, 0.02), new Vec3(sx * 0.32 + sway, -0.98, 0.08), 0.11f, 8, p, L);
                    FxDraw.cone(vc, ps, new Vec3(sx * 0.16, -0.5, 0.02), new Vec3(sx * 0.34 + sway, -1.04, 0.09), 0.15f, 8, edge, L);
                }
                case HORNS -> FxDraw.cone(vc, ps, new Vec3(sx * 0.17, -0.47, -0.05), new Vec3(sx * 0.36, -0.82, 0.18), 0.07f, 8, p, L);
                case OX_HORNS -> {
                    List<Vec3> pts = List.of(new Vec3(sx * 0.2, -0.42, 0), new Vec3(sx * 0.42, -0.5, 0.02),
                            new Vec3(sx * 0.56, -0.68, 0.0), new Vec3(sx * 0.55, -0.9, -0.06));
                    FxDraw.tube(vc, ps, pts, new float[]{0.08f, 0.065f, 0.045f, 0.012f}, 8, p, 1f, L, true);
                }
                case ANTENNAE -> {
                    List<Vec3> pts = List.of(new Vec3(sx * 0.08, -0.5, -0.1), new Vec3(sx * 0.14 + sway, -0.75, -0.18),
                            new Vec3(sx * 0.26 + sway, -0.98, -0.3));
                    FxDraw.tube(vc, ps, pts, new float[]{0.03f, 0.022f, 0.012f}, 6, p, 1f, L, true);
                }
                case SPIKES -> FxDraw.cone(vc, ps, new Vec3(sx * 0.13, -0.5, 0.05), new Vec3(sx * 0.2, -0.72, 0.16), 0.07f, 6, p, L);
                case NONE -> {
                }
            }
        }
        if (head == TailedBeast.HeadShape.SPIKES) FxDraw.cone(vc, ps, new Vec3(0, -0.5, 0.0), new Vec3(0, -0.82, 0.12), 0.08f, 6, p, L);
    }

    private static float[] rgb(int c) {
        return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }

    private static float lift(float v) {
        return Math.min(1f, v + (1f - v) * 0.25f);
    }

    private static int brighten(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return (Math.min(255, r + (255 - r) / 2) << 16) | (Math.min(255, g + (255 - g) / 2) << 8) | Math.min(255, b + (255 - b) / 2);
    }
}
