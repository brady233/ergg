package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Water Shark Bullet: a translucent shark of water swimming nose-first along its path, its tail sweeping from side to
 * side, jaws open with rows of white teeth, a tall dorsal fin, pectoral fins and pale glowing eyes.
 */
public final class WaterSharkRender {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/water_dragon.png");

    private WaterSharkRender() {}

    public static void render(JutsuProjectile shark, float partial, PoseStack ps, MultiBufferSource buffers, int packedLight) {
        float time = shark.tickCount + partial;
        float scale = shark.getScale();
        Vec3 v = shark.getDeltaMovement();
        Vec3 fwd = v.lengthSqr() > 1e-6 ? v.normalize() : Vec3.directionFromRotation(shark.getXRot(), shark.getYRot());
        Vec3 up = new Vec3(0, 1, 0);
        if (Math.abs(fwd.dot(up)) > 0.97) up = new Vec3(1, 0, 0);
        up = up.subtract(fwd.scale(up.dot(fwd))).normalize();
        Vec3 left = up.cross(fwd).normalize();
        int light = Math.max(packedLight & 0xFFFF, 0x90) | (packedLight & 0xFFFF0000);

        ps.pushPose();
        ps.translate(0, shark.getBbHeight() / 2.0, 0);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(TEXTURE));
        WaterDragonRender.Head h = new WaterDragonRender.Head(vc, ps.last().pose(), ps.last().normal(), Vec3.ZERO, left, up, fwd,
                0.55f * scale, light);
        float wag = 0.32f * Mth.sin(time * 0.9f);            // the tail sweeps side to side
        float jaw = 0.3f + 0.12f * Mth.sin(time * 0.5f);
        int r = 120, g = 185, b = 238, a = 205;
        // body, thick at the front and tapering back
        h.box(0, 0, 0.4f, 0.45f, 0.42f, 0.6f, 0, 0, 0, 0, 0, r, g, b, a);
        h.box(0, 0.01f, -0.5f, 0.38f, 0.36f, 0.45f, 0, 0, -0.1f, 0, wag * 0.3f, r, g, b, a);
        h.box(0, 0.02f, -1.2f, 0.24f, 0.24f, 0.4f, 0, 0, -0.8f, 0, wag * 0.7f, r, g, b, a);
        h.box(0, 0.03f, -1.7f, 0.12f, 0.14f, 0.3f, 0, 0, -0.8f, 0, wag, r, g, b, a);
        // tail fin: tall upper lobe, short lower lobe, both swept back
        h.box(0, 0.45f, -2.1f, 0.04f, 0.45f, 0.18f, 0, 0.05f, -1.95f, -0.55f, wag * 1.2f, 150, 205, 245, a);
        h.box(0, -0.32f, -2.05f, 0.04f, 0.3f, 0.15f, 0, 0, -1.95f, 0.6f, wag * 1.2f, 150, 205, 245, a);
        // head and snout
        h.box(0, 0.05f, 1.25f, 0.36f, 0.3f, 0.35f, 0, 0, 0, 0, 0, r, g, b, a);
        h.box(0, 0.12f, 1.65f, 0.25f, 0.18f, 0.15f, 0, 0, 0, 0, 0, r, g, b, a);
        // open lower jaw
        h.box(0, -0.38f, 1.3f, 0.3f, 0.08f, 0.4f, 0, -0.25f, 0.9f, jaw, 0, 105, 170, 230, a);
        for (int t = 0; t < 4; t++) {                         // teeth along the upper jaw
            float z = 1.12f + t * 0.15f;
            h.box(0.25f, -0.15f, z, 0.025f, 0.07f, 0.025f, 0, 0, 0, 0, 0, 245, 250, 255, 255);
            h.box(-0.25f, -0.15f, z, 0.025f, 0.07f, 0.025f, 0, 0, 0, 0, 0, 245, 250, 255, 255);
        }
        h.box(0, -0.26f, 1.62f, 0.2f, 0.025f, 0.025f, 0, 0, 0, 0, 0, 245, 250, 255, 255);
        // dorsal fin (leaning back) and pectoral fins
        h.box(0, 0.68f, -0.15f, 0.04f, 0.32f, 0.26f, 0, 0.42f, 0f, -0.45f, 0, 150, 205, 245, a);
        h.box(0.6f, -0.25f, 0.35f, 0.3f, 0.03f, 0.18f, 0.3f, -0.25f, 0.4f, 0, -0.4f, 150, 205, 245, a);
        h.box(-0.6f, -0.25f, 0.35f, 0.3f, 0.03f, 0.18f, -0.3f, -0.25f, 0.4f, 0, 0.4f, 150, 205, 245, a);
        // eyes
        h.light = LightTexture.FULL_BRIGHT;
        h.box(0.37f, 0.15f, 1.15f, 0.03f, 0.07f, 0.07f, 0, 0, 0, 0, 0, 255, 255, 255, 255);
        h.box(-0.37f, 0.15f, 1.15f, 0.03f, 0.07f, 0.07f, 0, 0, 0, 0, 0, 255, 255, 255, 255);
        ps.popPose();
    }
}
