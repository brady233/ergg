package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.fx.Fx;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** The jutsu effects playing right now (sent by the server, see fx/Fx), drawn every frame until they run out. */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class FxClient {
    /** One effect playing. {@code start} is the game time it began. */
    public static final class Active {
        public final Fx.Visual type;
        public final Vec3 a, b;
        public final int entityA, entityB, ticks, seed;
        public final float size;
        public final long start;

        Active(Fx.Visual type, Vec3 a, Vec3 b, int entityA, int entityB, float size, int ticks, int seed, long start) {
            this.type = type;
            this.a = a;
            this.b = b;
            this.entityA = entityA;
            this.entityB = entityB;
            this.size = size;
            this.ticks = ticks;
            this.seed = seed;
            this.start = start;
        }

        /** The followed creature, or null if it's gone. */
        public Entity entityA() {
            ClientLevel level = Minecraft.getInstance().level;
            return level == null || entityA < 0 ? null : level.getEntity(entityA);
        }

        public Entity entityB() {
            ClientLevel level = Minecraft.getInstance().level;
            return level == null || entityB < 0 ? null : level.getEntity(entityB);
        }
    }

    /** What a renderer gets: where to draw, and how far along the effect is. */
    public record Ctx(PoseStack ps, MultiBufferSource buffers, Camera camera, Vec3 cam, float partial, float age, Active fx) {
        /** 0 at the start, 1 at the end. */
        public float progress() {
            return fx.ticks <= 0 ? 1f : Math.min(1f, age / fx.ticks);
        }
    }

    private static final List<Active> ACTIVE = new ArrayList<>();

    private FxClient() {}

    public static void add(int type, Vec3 a, Vec3 b, int entityA, int entityB, float size, int ticks, int seed) {
        Minecraft mc = Minecraft.getInstance();
        Fx.Visual t = Fx.Visual.byId(type);
        if (t == null || mc.level == null) return;
        Active fx = new Active(t, a, b, entityA, entityB, size, ticks, seed, mc.level.getGameTime());
        ACTIVE.add(fx);
        FxRenderers.started(fx);
    }

    /** Effects of a type that are still playing (some, like Lightning Armor's, are looked up while drawing a player). */
    public static List<Active> active() {
        return ACTIVE;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            ACTIVE.clear();
            return;
        }
        if (mc.isPaused()) return;
        long now = mc.level.getGameTime();
        Iterator<Active> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Active fx = it.next();
            float age = now - fx.start;
            if (age > fx.ticks + 2) {
                it.remove();
                continue;
            }
            FxRenderers.tick(fx, age);
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float partial = event.getPartialTick();
        float now = mc.level.getGameTime() + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        for (Active fx : new ArrayList<>(ACTIVE)) {
            float age = now - fx.start;
            if (age < 0 || age > fx.ticks) continue;
            try {
                FxRenderers.render(new Ctx(ps, buffers, camera, cam, partial, age, fx));
            } catch (RuntimeException e) {
                ShinobiArts.LOGGER.debug("jutsu effect {} failed to draw", fx.type, e);
            }
        }
        buffers.endBatch();
        ps.popPose();
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
