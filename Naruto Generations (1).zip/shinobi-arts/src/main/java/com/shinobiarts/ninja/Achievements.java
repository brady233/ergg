package com.shinobiarts.ninja;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.jutsu.Jutsu;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * The mod's advancements (data/shinobiarts/advancements, made by tools/make_resources.py). They have no triggers of
 * their own ("minecraft:impossible"); this hands them out every second from the player's ninja data:
 * <ul>
 *   <li>jutsu/&lt;id&gt; for every jutsu learned, under release/&lt;nature&gt; for every release unlocked;</li>
 *   <li>dojutsu/...: each Sharingan stage, the Mangekyou and its pattern, the Eternal Mangekyou, the Byakugan, the Rinnegan;</li>
 *   <li>clan/&lt;id&gt; once the player's clan is theirs for good (claimed with /clanroll claim, or no rolls left).
 *       Clan advancements are announced in chat, so everyone sees which clan a player belongs to. If an admin
 *       changes the clan later, the old clan's advancement is taken back.</li>
 * </ul>
 * Players who already had jutsu, releases or eyes before this get those advancements the first time they log in.
 */
public final class Achievements {
    private Achievements() {}

    public static void check(ServerPlayer p, NinjaData d) {
        if (!d.isInitialized()) return;
        for (Jutsu j : d.learnedJutsu()) award(p, "jutsu/" + j.id());
        for (ChakraNature n : ChakraNature.values()) {
            if (d.hasNature(n)) award(p, "release/" + n.id());
        }

        int stage = d.getSharinganStage();
        for (int s = 1; s <= Math.min(stage, 3); s++) award(p, "dojutsu/sharingan_" + s);
        if (stage >= Dojutsu.MANGEKYOU) {
            award(p, "dojutsu/sharingan_3"); // an implanted Mangekyou counts for the stages before it
            award(p, "dojutsu/mangekyou");
            award(p, "dojutsu/mangekyou_" + d.getBaseMangekyouDesign().id());
            if (d.hasEternal()) award(p, "dojutsu/mangekyou_eternal");
        }
        if (d.availableDojutsu().contains(Dojutsu.BYAKUGAN)) award(p, "dojutsu/byakugan");
        if (d.hasRinnegan()) award(p, "dojutsu/rinnegan");
        if (d.getSusanooStage() >= 1) award(p, "dojutsu/susanoo");
        if (d.getSusanooStage() >= 5) award(p, "dojutsu/perfect_susanoo");

        Clan clan = d.getClan();
        boolean final_ = d.isClanFinal();
        for (Clan c : Clan.values()) {
            if (c == Clan.NONE) continue;
            if (final_ && c == clan) award(p, "clan/" + c.id());
            else revoke(p, "clan/" + c.id());
        }
    }

    private static void award(ServerPlayer p, String path) {
        Advancement adv = p.server.getAdvancements().getAdvancement(ShinobiArts.id(path));
        if (adv == null) return;
        PlayerAdvancements advancements = p.getAdvancements();
        AdvancementProgress progress = advancements.getOrStartProgress(adv);
        if (progress.isDone()) return;
        List<String> remaining = new ArrayList<>();
        for (String criterion : progress.getRemainingCriteria()) remaining.add(criterion);
        for (String criterion : remaining) advancements.award(adv, criterion);
    }

    private static void revoke(ServerPlayer p, String path) {
        Advancement adv = p.server.getAdvancements().getAdvancement(ShinobiArts.id(path));
        if (adv == null) return;
        PlayerAdvancements advancements = p.getAdvancements();
        AdvancementProgress progress = advancements.getOrStartProgress(adv);
        if (!progress.hasProgress()) return;
        List<String> done = new ArrayList<>();
        for (String criterion : progress.getCompletedCriteria()) done.add(criterion);
        for (String criterion : done) advancements.revoke(adv, criterion);
    }
}
