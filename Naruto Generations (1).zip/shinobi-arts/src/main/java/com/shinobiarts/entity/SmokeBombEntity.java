package com.shinobiarts.entity;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import com.shinobiarts.util.Scheduler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * A thrown smoke bomb: it bursts where it lands into a thick cloud of grey smoke. Anyone inside (except whoever
 * threw it) is blinded, and creatures lose track of who they were after: cover to get away or close in.
 */
public class SmokeBombEntity extends ThrowableItemProjectile {
    public SmokeBombEntity(EntityType<? extends SmokeBombEntity> type, Level level) {
        super(type, level);
    }

    public SmokeBombEntity(Level level, LivingEntity owner) {
        super(ModEntities.SMOKE_BOMB.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SMOKE_BOMB.get();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide || isRemoved()) return;
        burst((ServerLevel) level(), result.getLocation(), getOwner());
        discard();
    }

    static void burst(ServerLevel level, Vec3 at, Entity owner) {
        double radius = Config.d(Config.SMOKE_RADIUS);
        int seconds = Config.i(Config.SMOKE_SECONDS);
        Fx.at(level, Fx.Visual.SMOKE_BOMB, at, (float) radius, seconds * 20);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 1.2f, 0.6f);
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.4f, 1.8f);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y + 0.5, at.z, 40, radius * 0.3, 0.6, radius * 0.3, 0.05);
        Scheduler.repeat(0, 10, seconds * 2, i -> {
            AABB box = new AABB(at, at).inflate(radius, radius * 0.7, radius);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e.isAlive() && e != owner)) {
                if (e.position().distanceToSqr(at) > radius * radius * 1.2) continue;
                e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, false));
                if (e instanceof Mob mob) mob.setTarget(null);
            }
            if (i % 4 == 0) level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, at.x, at.y + 0.5, at.z, 6, radius * 0.4, 0.4, radius * 0.4, 0.01);
        });
    }
}
