package com.shinobiarts.entity;

import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** A thrown kunai or shuriken. Drops back as an item where it lands so it can be picked up. */
public class ThrownToolEntity extends ThrowableItemProjectile {
    public ThrownToolEntity(EntityType<? extends ThrownToolEntity> type, Level level) {
        super(type, level);
    }

    public ThrownToolEntity(Level level, LivingEntity owner) {
        super(ModEntities.THROWN_TOOL.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.KUNAI.get();
    }

    @Override
    protected float getGravity() {
        return 0.015f;
    }

    private boolean isShuriken() {
        return getItem().is(ModItems.SHURIKEN.get());
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity owner = getOwner();
        float damage = isShuriken() ? 4.0f : 6.0f;
        if (owner instanceof net.minecraft.world.entity.player.Player player) {
            com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(player);
            if (d != null) damage *= 1f + d.getClan().buffs().thrown(); // Fuma, Shirogane
        }
        result.getEntity().hurt(damageSources().thrown(this, owner), damage);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide || isRemoved()) return;
        playSound(SoundEvents.ARROW_HIT, 0.8f, isShuriken() ? 1.6f : 1.2f);
        boolean creativeOwner = getOwner() instanceof Player p && p.getAbilities().instabuild;
        if (!creativeOwner) spawnAtLocation(getItem().copy(), 0.1f);
        discard();
    }
}
