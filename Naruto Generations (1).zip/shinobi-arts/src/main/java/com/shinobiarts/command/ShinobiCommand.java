package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Rank;
import com.shinobiarts.ninja.Stat;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /shinobi info [player]                     - show clan, natures, chakra and jutsu
 * /shinobi clan <player> <clan>              - change clan (op)
 * /shinobi nature <player> <nature>          - reveal affinity + unlock a nature (op)
 * /shinobi learn <player> <jutsu|all>        - teach a jutsu, ignoring requirements (op)
 * /shinobi forget <player> <jutsu|all>       - forget a jutsu (op)
 * /shinobi xp <player> <amount>              - give ninja XP (op)
 * /shinobi level <player> <level>            - set level (up to the rank's cap); stat points recalculated (op)
 * /shinobi rank <player> <rank>              - promote/demote: genin, chunin, jonin, anbu, sannin (op)
 * /shinobi ryo <player> add|set <amount>     - change a player's Ryo (op)
 * /shinobi release <player> <release>        - give a release scroll (op)
 * /shinobi refill <player>                   - refill chakra and Senjutsu, clear cooldowns (op)
 * /shinobi reset <player>                    - re-roll as a brand new ninja (op)
 */
public final class ShinobiCommand {
    private static final SuggestionProvider<CommandSourceStack> DESIGNS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(com.shinobiarts.ninja.MangekyouDesign.values()).map(com.shinobiarts.ninja.MangekyouDesign::id), builder);
    private static final SuggestionProvider<CommandSourceStack> CLANS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Clan.values()).map(Clan::id), builder);
    private static final SuggestionProvider<CommandSourceStack> NATURES = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(ChakraNature.NATURES).map(ChakraNature::id), builder);
    private static final SuggestionProvider<CommandSourceStack> RANKS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Rank.values()).map(Rank::id), builder);
    private static final SuggestionProvider<CommandSourceStack> RELEASES = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(ChakraNature.RELEASES).map(ChakraNature::id), builder);
    private static final SuggestionProvider<CommandSourceStack> JUTSU = (ctx, builder) -> {
        List<String> ids = new ArrayList<>();
        ids.add("all");
        for (Jutsu j : Jutsus.all()) ids.add(j.id());
        return SharedSuggestionProvider.suggest(ids, builder);
    };

    private ShinobiCommand() {}

    /** /shinobi lb [kills|kd|streak|bounty]: the top 10 PvP ninja, and where you stand. */
    private static int leaderboard(CommandSourceStack source, String by) {
        com.shinobiarts.pvp.ShinobiRecords records = com.shinobiarts.pvp.ShinobiRecords.get(source.getServer());
        if (source.getEntity() instanceof ServerPlayer self) records.of(self);
        String sort = switch (by.toLowerCase()) {
            case "kd", "k/d" -> "kd";
            case "streak", "streaks" -> "streak";
            case "bounty", "bounties" -> "bounty";
            default -> "kills";
        };
        java.util.List<com.shinobiarts.pvp.ShinobiRecords.Record> list = records.records();
        java.util.Comparator<com.shinobiarts.pvp.ShinobiRecords.Record> order = switch (sort) {
            case "kd" -> java.util.Comparator.comparingDouble(r -> r.kd());
            case "streak" -> java.util.Comparator.comparingInt(r -> r.bestStreak);
            case "bounty" -> java.util.Comparator.comparingLong(r -> r.bounty);
            default -> java.util.Comparator.comparingInt(r -> r.kills);
        };
        list.sort(order.reversed().thenComparing(r -> r.name.toLowerCase()));
        if (!sort.equals("bounty")) list.removeIf(r -> r.kills == 0 && r.deaths == 0);
        else list.removeIf(r -> r.bounty <= 0);
        source.sendSuccess(() -> Component.translatable("message.shinobiarts.lb_title",
                Component.translatable("message.shinobiarts.lb_" + sort)).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        if (list.isEmpty()) {
            source.sendSuccess(() -> Component.translatable("message.shinobiarts.lb_empty").withStyle(ChatFormatting.GRAY), false);
            return 0;
        }
        ChatFormatting[] medal = {ChatFormatting.GOLD, ChatFormatting.WHITE, ChatFormatting.RED};
        for (int i = 0; i < Math.min(10, list.size()); i++) {
            com.shinobiarts.pvp.ShinobiRecords.Record r = list.get(i);
            int place = i + 1;
            ChatFormatting c = i < 3 ? medal[i] : ChatFormatting.GRAY;
            source.sendSuccess(() -> Component.literal("#" + place + " ").withStyle(c, ChatFormatting.BOLD)
                    .append(Component.literal(r.name).withStyle(ChatFormatting.WHITE))
                    .append(Component.literal("  " + lbValue(r, sort)).withStyle(ChatFormatting.YELLOW))
                    .append(Component.literal(r.village.isEmpty() ? "" : "  [" + r.village + "]").withStyle(ChatFormatting.DARK_GRAY)), false);
        }
        if (source.getEntity() instanceof ServerPlayer self) {
            for (int i = 0; i < list.size(); i++) {
                if (!list.get(i).id.equals(self.getUUID())) continue;
                int place = i + 1;
                com.shinobiarts.pvp.ShinobiRecords.Record r = list.get(i);
                source.sendSuccess(() -> Component.translatable("message.shinobiarts.lb_you", place, lbValue(r, sort)).withStyle(ChatFormatting.AQUA), false);
            }
        }
        return list.size();
    }

    private static String lbValue(com.shinobiarts.pvp.ShinobiRecords.Record r, String sort) {
        return switch (sort) {
            case "kd" -> String.format("%.2f K/D (%d/%d)", r.kd(), r.kills, r.deaths);
            case "streak" -> r.bestStreak + " best streak";
            case "bounty" -> com.shinobiarts.ninja.PlayerDataManager.formatRyo(r.bounty) + " Ryo";
            default -> r.kills + " kills (" + r.deaths + " deaths)";
        };
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shinobi")
                .then(Commands.literal("lb")
                        .executes(ctx -> leaderboard(ctx.getSource(), "kills"))
                        .then(Commands.argument("by", com.mojang.brigadier.arguments.StringArgumentType.word())
                                .suggests((ctx, b) -> net.minecraft.commands.SharedSuggestionProvider.suggest(new String[]{"kills", "kd", "streak", "bounty"}, b))
                                .executes(ctx -> leaderboard(ctx.getSource(),
                                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "by")))))
                .then(Commands.literal("info")
                        .executes(ctx -> info(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(s -> s.hasPermission(2))
                                .executes(ctx -> info(ctx, EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("clan").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("clan", StringArgumentType.word()).suggests(CLANS)
                                        .executes(ShinobiCommand::setClan))))
                .then(Commands.literal("clanroll").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.literal("reset").executes(ShinobiCommand::resetClanRolls))))
                .then(Commands.literal("nature").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("nature", StringArgumentType.word()).suggests(NATURES)
                                        .executes(ShinobiCommand::unlockNature))))
                .then(Commands.literal("learn").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("jutsu", StringArgumentType.word()).suggests(JUTSU)
                                        .executes(ctx -> learn(ctx, true)))))
                .then(Commands.literal("forget").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("jutsu", StringArgumentType.word()).suggests(JUTSU)
                                        .executes(ctx -> learn(ctx, false)))))
                .then(Commands.literal("xp").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", LongArgumentType.longArg(1))
                                        .executes(ShinobiCommand::xp))))
                .then(Commands.literal("level").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("level", IntegerArgumentType.integer(1))
                                        .executes(ShinobiCommand::level))))
                .then(Commands.literal("rank").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("rank", StringArgumentType.word()).suggests(RANKS)
                                        .executes(ShinobiCommand::rank))))
                .then(Commands.literal("ryo").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.literal("add").then(Commands.argument("amount", LongArgumentType.longArg(1))
                                        .executes(ctx -> ryo(ctx, true))))
                                .then(Commands.literal("set").then(Commands.argument("amount", LongArgumentType.longArg(0))
                                        .executes(ctx -> ryo(ctx, false))))))
                .then(Commands.literal("jutsupoints").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.literal("add").then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                        .executes(ctx -> jutsuPoints(ctx, true))))
                                .then(Commands.literal("set").then(Commands.argument("amount", IntegerArgumentType.integer(0))
                                        .executes(ctx -> jutsuPoints(ctx, false))))))
                .then(Commands.literal("release").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("release", StringArgumentType.word()).suggests(RELEASES)
                                        .executes(ShinobiCommand::giveRelease))))
                .then(Commands.literal("sharingan").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("stage", IntegerArgumentType.integer(0, 4))
                                        .executes(ShinobiCommand::sharingan))))
                .then(Commands.literal("mangekyou").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("pattern", StringArgumentType.word()).suggests(DESIGNS)
                                        .executes(ShinobiCommand::mangekyou))))
                .then(Commands.literal("refill").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ShinobiCommand::refill)))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ShinobiCommand::reset))));
    }

    private static NinjaData data(ServerPlayer player) throws CommandSyntaxException {
        NinjaData data = NinjaData.get(player);
        if (data == null) throw EntityArgument.NO_PLAYERS_FOUND.create();
        return data;
    }

    private static int info(CommandContext<CommandSourceStack> ctx, ServerPlayer player) throws CommandSyntaxException {
        NinjaData d = data(player);
        String natures = d.getNatures().isEmpty() ? "-" : d.getNatures().stream().map(ChakraNature::id).collect(Collectors.joining(", "));
        String jutsu = d.learnedJutsu().stream().map(Jutsu::id).collect(Collectors.joining(", "));
        MutableComponent msg = Component.literal("")
                .append(Component.literal(player.getGameProfile().getName()).withStyle(ChatFormatting.GOLD))
                .append(Component.literal("\nClan: ")).append(d.getClan().displayName())
                .append(Component.literal("\nAffinity: ")).append(d.getAffinity().displayName())
                .append(Component.literal(d.isAffinityRevealed() ? "" : " (hidden)"))
                .append(Component.literal("\nNatures: " + natures))
                .append(Component.literal("\nRank: ")).append(d.getRank().displayName())
                .append(Component.literal(" (level cap " + d.getRank().capText() + ")"))
                .append(Component.literal(String.format("\nLevel %d (%d / %d XP), %d unspent stat points", d.getLevel(), d.getXp(), d.xpToNext(), d.availablePoints())))
                .append(Component.literal("\nStats: " + Arrays.stream(Stat.values()).map(st -> st.id() + " " + d.stat(st)).collect(Collectors.joining(", "))))
                .append(Component.literal(String.format("\nChakra: %d / %d, Senjutsu: %d / %d", (int) d.getChakra(), (int) d.maxChakra(), (int) d.getSenjutsu(), (int) d.maxSenjutsu())))
                .append(Component.literal("\nRyo: " + PlayerDataManager.formatRyo(d.getRyo())))
                .append(Component.literal("\nSharingan: ")).append(d.getSharinganStage() == 0 ? Component.literal("none")
                        : com.shinobiarts.ninja.Dojutsu.sharinganName(d.getSharinganStage()))
                .append(Component.literal("\nJutsu: " + (jutsu.isEmpty() ? "-" : jutsu)));
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }

    private static int setClan(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        Clan clan = Clan.byId(StringArgumentType.getString(ctx, "clan"));
        if (clan == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown clan. /clan list shows them all."));
            return 0;
        }
        NinjaData d = data(player);
        d.setClan(clan);
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " is now of the ").append(clan.displayName()).append(" clan"), true);
        return 1;
    }

    /** Admin: gives a player their clan rolls back and unlocks their clan (they keep it until they roll). */
    private static int resetClanRolls(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        NinjaData d = data(player);
        d.setClanRolls(0);
        d.setClanClaimed(false);
        d.clearRolledClans();
        ModNetwork.sync(player);
        com.shinobiarts.event.CommonEvents.clanRollIntro(player);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " can roll their clan again"), true);
        return 1;
    }

    /** Admin: sets a player's Sharingan stage directly (0 = none, 1-3 tomoe, 4 = Mangekyou). */
    private static int sharingan(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        int stage = IntegerArgumentType.getInteger(ctx, "stage");
        NinjaData d = data(player);
        d.setSharinganStage(stage);
        ModNetwork.sync(player);
        com.shinobiarts.ninja.SharinganManager.broadcastEyes(player);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + ": ")
                .append(stage == 0 ? Component.literal("no Sharingan") : com.shinobiarts.ninja.Dojutsu.sharinganName(stage, d.getMangekyouDesign())), true);
        return 1;
    }

    /** Admin: gives a player the Mangekyou in a pattern (itachi, sasuke, obito, eternal). */
    private static int mangekyou(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String id = StringArgumentType.getString(ctx, "pattern");
        com.shinobiarts.ninja.MangekyouDesign design = null;
        for (com.shinobiarts.ninja.MangekyouDesign d : com.shinobiarts.ninja.MangekyouDesign.values()) {
            if (d.id().equals(id)) design = d;
        }
        if (design == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown pattern. Options: itachi, sasuke, obito, eternal"));
            return 0;
        }
        NinjaData d = data(player);
        d.setSharinganStage(com.shinobiarts.ninja.Dojutsu.MANGEKYOU);
        // a pattern replaces the Eternal eyes; "eternal" adds them on top of the pattern the player has
        if (design != com.shinobiarts.ninja.MangekyouDesign.ETERNAL) d.setEternalUnlocked(false);
        d.setMangekyouDesign(design);
        d.setSharinganMode(design == com.shinobiarts.ninja.MangekyouDesign.ETERNAL ? 2 : 1);
        ModNetwork.sync(player);
        com.shinobiarts.ninja.SharinganManager.broadcastEyes(player);
        com.shinobiarts.ninja.EyeTechniques.explain(player, d);
        com.shinobiarts.ninja.MangekyouDesign chosen = design;
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + ": ")
                .append(com.shinobiarts.ninja.Dojutsu.sharinganName(com.shinobiarts.ninja.Dojutsu.MANGEKYOU, chosen)), true);
        return 1;
    }

    private static int unlockNature(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        ChakraNature nature = ChakraNature.byId(StringArgumentType.getString(ctx, "nature"));
        if (nature == null || !nature.isElement()) {
            ctx.getSource().sendFailure(Component.literal("Unknown nature. Options: fire, water, wind, lightning, earth, yin_yang"));
            return 0;
        }
        NinjaData d = data(player);
        d.revealAffinity();
        d.unlockNature(nature);
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Unlocked ").append(nature.displayName()).append(" for " + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int learn(CommandContext<CommandSourceStack> ctx, boolean learn) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String id = StringArgumentType.getString(ctx, "jutsu");
        NinjaData d = data(player);
        if (id.equals("all")) {
            for (Jutsu j : Jutsus.all()) {
                if (learn) d.learn(j.id());
                else d.forget(j.id());
            }
        } else {
            Jutsu j = Jutsus.get(id);
            if (j == null) {
                ctx.getSource().sendFailure(Component.literal("Unknown jutsu: " + id));
                return 0;
            }
            if (learn) d.learn(j.id());
            else d.forget(j.id());
        }
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal((learn ? "Taught " : "Removed ") + id + (learn ? " to " : " from ") + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int xp(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        data(player);
        PlayerDataManager.addXp(player, amount);
        ctx.getSource().sendSuccess(() -> Component.literal("Gave " + amount + " XP to " + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int level(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        int level = IntegerArgumentType.getInteger(ctx, "level");
        NinjaData d = data(player);
        PlayerDataManager.setLevel(player, level);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " is now level " + d.getLevel()), true);
        return 1;
    }

    private static int rank(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        Rank rank = Rank.byId(StringArgumentType.getString(ctx, "rank"));
        if (rank == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown rank. Options: genin, chunin, jonin, anbu, sannin"));
            return 0;
        }
        data(player);
        PlayerDataManager.setRank(player, rank);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " is now ").append(rank.displayName()), true);
        return 1;
    }

    private static int ryo(CommandContext<CommandSourceStack> ctx, boolean add) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        NinjaData d = data(player);
        if (add) PlayerDataManager.addRyo(player, amount);
        else PlayerDataManager.setRyo(player, amount);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " now has "
                + PlayerDataManager.formatRyo(d.getRyo()) + " Ryo"), true);
        return 1;
    }

    private static int jutsuPoints(CommandContext<CommandSourceStack> ctx, boolean add) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        NinjaData d = data(player);
        d.setJutsuPoints(add ? d.getJutsuPoints() + amount : amount);
        PlayerDataManager.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " now has "
                + d.getJutsuPoints() + " Jutsu Points"), true);
        return 1;
    }

    private static int giveRelease(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        ChakraNature release = ChakraNature.byId(StringArgumentType.getString(ctx, "release"));
        if (release == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown release. Options: fire, water, wind, lightning, earth, yin_yang, ninjutsu"));
            return 0;
        }
        ReleaseItem.give(player, release);
        return 1;
    }

    private static int refill(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        NinjaData d = data(player);
        d.setChakra(d.maxChakra());
        d.setSenjutsu(d.maxSenjutsu());
        d.clearCooldowns();
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Refilled " + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        NinjaData d = data(player);
        d.init(player.getRandom());
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        com.shinobiarts.event.CommonEvents.clanRollIntro(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Reset " + player.getGameProfile().getName()), true);
        return 1;
    }
}
