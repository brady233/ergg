package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.TailedBeast;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;

/**
 * /jinchuriki give &lt;player&gt; &lt;beast&gt; (by name, e.g. kurama, or tail count), /jinchuriki remove &lt;player&gt;,
 * /jinchuriki info &lt;player&gt;. Operators only.
 */
public final class JinchurikiCommand {
    private JinchurikiCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("jinchuriki").requires(s -> s.hasPermission(2))
                .then(Commands.literal("give").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("beast", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Arrays.stream(TailedBeast.values()).map(t -> t.id), b))
                                .executes(ctx -> {
                                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                                    TailedBeast beast = TailedBeast.byId(StringArgumentType.getString(ctx, "beast"));
                                    if (beast == null) {
                                        ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.jin_unknown"));
                                        return 0;
                                    }
                                    Jinchuriki.give(p, beast);
                                    ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.jin_gave", p.getDisplayName(),
                                            beast.displayName()), true);
                                    return 1;
                                }))))
                .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                    Jinchuriki.remove(p);
                    ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.jin_took", p.getDisplayName()), true);
                    return 1;
                })))
                .then(Commands.literal("info").then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                    NinjaData d = NinjaData.get(p);
                    TailedBeast b = d == null ? null : d.jin.beast();
                    if (b == null) {
                        ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.jin_info_none", p.getDisplayName())
                                .withStyle(ChatFormatting.GRAY), false);
                        return 1;
                    }
                    ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.jin_info", p.getDisplayName(), b.displayName(),
                            d.jin.unlocked, d.jin.cloak ? "yes" : "no"), false);
                    return 1;
                }))));
    }
}
