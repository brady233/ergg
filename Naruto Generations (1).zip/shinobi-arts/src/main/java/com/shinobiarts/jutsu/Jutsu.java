package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import javax.annotation.Nullable;

/**
 * One technique. The {@link Action} does the actual work on the server and returns false
 * if the jutsu fizzled (no target, no room...), in which case no chakra or cooldown is spent.
 */
public final class Jutsu {
    @FunctionalInterface
    public interface Action {
        boolean perform(ServerPlayer player, NinjaData data);
    }

    private final String id;
    private final ChakraNature nature;
    @Nullable
    private final Clan clan;
    private final JutsuRank rank;
    private final int cooldown;
    private final boolean needsDojutsu;
    private final Action action;

    Jutsu(String id, ChakraNature nature, @Nullable Clan clan, JutsuRank rank, int cooldownTicks, boolean needsDojutsu, Action action) {
        this.id = id;
        this.nature = nature;
        this.clan = clan;
        this.rank = rank;
        this.cooldown = cooldownTicks;
        this.needsDojutsu = needsDojutsu;
        this.action = action;
    }

    public String id() {
        return id;
    }

    public ChakraNature nature() {
        return nature;
    }

    /** Clan that is allowed to learn this jutsu (set directly, or the clan of its clan release), or null if anyone can. */
    @Nullable
    public Clan clan() {
        return clan != null ? clan : nature.clan();
    }

    /** D (weakest) to S (strongest), as in the show. */
    public JutsuRank rank() {
        return rank;
    }

    /** Share of max chakra this jutsu costs ("chakraCost" in its section of Jutsus.toml, times chakraCostMultiplier). */
    public float costShare() {
        com.shinobiarts.Config.JutsuValues v = com.shinobiarts.Config.jutsu(id);
        double share = v == null ? 0.25 : com.shinobiarts.Config.d(v.chakraCost());
        return (float) (share * com.shinobiarts.Config.d(com.shinobiarts.Config.CHAKRA_COST_MULTIPLIER));
    }

    /** Chakra this jutsu costs the player: its share of their max chakra. */
    public float cost(NinjaData data) {
        return data.maxChakra() * costShare();
    }

    /** Cooldown in ticks before the global multiplier and clan bonuses ("cooldownSeconds" in Jutsus.toml). */
    public int cooldown() {
        com.shinobiarts.Config.JutsuValues v = com.shinobiarts.Config.jutsu(id);
        return v == null ? cooldown : (int) Math.round(com.shinobiarts.Config.d(v.cooldownSeconds()) * 20.0);
    }

    /** The cooldown this jutsu was registered with (the config's default), in ticks. */
    public int baseCooldown() {
        return cooldown;
    }

    /** This jutsu's own damage multiplier ("damageMultiplier" in Jutsus.toml). */
    public float damageMultiplier() {
        com.shinobiarts.Config.JutsuValues v = com.shinobiarts.Config.jutsu(id);
        return v == null ? 1f : com.shinobiarts.Config.f(v.damage());
    }

    /** The cooldown a player actually gets: global multiplier and their clan's shorter cooldowns applied. */
    public long cooldownFor(NinjaData data) {
        return Math.max(1L, Math.round(cooldown() * com.shinobiarts.Config.d(com.shinobiarts.Config.COOLDOWN_MULTIPLIER)
                * (1.0 - data.getClan().buffs().cooldown())));
    }

    public boolean needsDojutsu() {
        return needsDojutsu;
    }

    public Action action() {
        return action;
    }

    /** Minimum player level needed to learn this from a scroll (set per rank in the config). */
    public int requiredLevel() {
        return rank.requiredLevel();
    }

    /**
     * The release whose slots this jutsu goes into: its nature's, including the clan releases (Wood...). The older
     * clan techniques (Shadow Possession, Palm Rotation) and non-elemental jutsu belong to Ninjutsu.
     */
    public ChakraNature release() {
        return clan != null ? ChakraNature.NONE : nature;
    }

    /** Texture group for the scroll item: fire, water, wind, lightning, earth, wood..., basic or clan. */
    public String category() {
        if (clan != null) return "clan";
        return nature == ChakraNature.NONE ? "basic" : nature.id();
    }

    public MutableComponent displayName() {
        return Component.translatable("jutsu.shinobiarts." + id).withStyle(clan != null ? clan.color() : nature.color());
    }

    public MutableComponent description() {
        return Component.translatable("jutsu.shinobiarts." + id + ".desc");
    }
}
