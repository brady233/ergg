package com.shinobiarts.jutsu;

import com.shinobiarts.Config;

/**
 * Hold-to-charge casting. Holding right-click with a release charges its selected jutsu (like drawing a bow);
 * letting go casts it. Past a full charge it overcharges, up to 10: no more damage, but the jutsu grows (see size()). A quick tap casts at {@code chargeMinPower} of its damage and a full charge at
 * {@code chargeMaxPower}; how long a full charge takes is {@code chargeSeconds}. All three are set per jutsu. Only jutsu that deal damage
 * charge: utility jutsu (Substitution, armors, walls, healing...) still go off the moment you right-click.
 * Shared by the server (the cast) and the client (the charge counter on screen).
 */
public final class JutsuCharge {
    private JutsuCharge() {}

    /** Held jutsu: they last as long as right-click is held down (Water Prison), instead of charging. */
    public static boolean held(Jutsu jutsu) {
        return jutsu == Jutsus.WATER_PRISON;
    }

    /** Area jutsu that don't deal upgradeable damage but still charge, so they can be overcharged to a huge size. */
    private static final java.util.Set<String> AREA = java.util.Set.of("shinra_tensei", "chibaku_tensei", "tengai_shinsei", "poison_mist", "mind_fog");

    public static boolean chargeable(Jutsu jutsu) {
        if (held(jutsu)) return false;
        return Config.b(Config.CHARGE_ENABLED) && !Config.banned(jutsu.id()) && (Jutsus.upgradeable(jutsu) || AREA.contains(jutsu.id()));
    }

    /** Ticks for a full charge ("chargeSeconds" in the jutsu's section of Jutsus.toml: 0.5 s for D up to 2.5 s for S). */
    public static int fullChargeTicks(Jutsu jutsu) {
        Config.JutsuValues v = Config.jutsu(jutsu.id());
        double seconds = v == null ? 1.0 : Config.d(v.chargeSeconds());
        return Math.max(1, (int) Math.round(seconds * 20.0));
    }

    /** 0..1: how charged the jutsu is after holding for {@code ticks}. */
    public static float fraction(Jutsu jutsu, int ticks) {
        return Math.min(1f, Math.max(0f, ticks / (float) fullChargeTicks(jutsu)));
    }

    /** Ticks of overcharging after a full charge to reach the max charge ("overchargeSeconds"). */
    public static int overchargeTicks() {
        return Math.max(1, (int) Math.round(Config.d(Config.OVERCHARGE_SECONDS) * 20.0));
    }

    private static float minPower(Jutsu jutsu) {
        Config.JutsuValues v = Config.jutsu(jutsu.id());
        return v == null ? 0.6f : Config.f(v.chargeMinPower());
    }

    private static float maxPower(Jutsu jutsu) {
        Config.JutsuValues v = Config.jutsu(jutsu.id());
        return Math.max(minPower(jutsu), v == null ? 1.5f : Config.f(v.chargeMaxPower()));
    }

    /** The highest the counter goes ("maxCharge", 10 by default). */
    public static float maxCharge(Jutsu jutsu) {
        return Math.max(maxPower(jutsu), Config.f(Config.MAX_CHARGE));
    }

    /**
     * The charge counter: chargeMinPower at a tap, chargeMaxPower (1.5) at a full charge, then on up to maxCharge (10)
     * while it's held longer (overcharging).
     */
    public static float value(Jutsu jutsu, float ticks) {
        float min = minPower(jutsu), max = maxPower(jutsu);
        int full = fullChargeTicks(jutsu);
        if (ticks <= full) return min + (max - min) * Math.max(0f, ticks / full);
        float over = Math.min(1f, (ticks - full) / overchargeTicks());
        return max + (maxCharge(jutsu) - max) * over;
    }

    /** Damage multiplier for a charge: it stops growing at chargeMaxPower (1.5); overcharging doesn't add damage. */
    public static float power(Jutsu jutsu, int ticks) {
        return Math.min(value(jutsu, ticks), maxPower(jutsu));
    }

    /** How much bigger an overcharged jutsu is (size and radius): 1 up to a full charge, then charge / chargeMaxPower. */
    public static float size(Jutsu jutsu, float ticks) {
        float max = maxPower(jutsu);
        return max <= 0 ? 1f : Math.max(1f, value(jutsu, ticks) / max);
    }
}
