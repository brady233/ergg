package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.network.MindLinkPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Afflictions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Mind Body Transfer (Yamanaka): the caster's mind leaves their body and enters the creature they look at. Their
 * view moves into its eyes, and their movement keys, mouse and attacks now drive its body, while their own body stands
 * empty and helpless. Whatever the borrowed body suffers, the caster's own body feels (a share of the damage). It ends
 * after mindTransferSeconds, when the caster sneaks, or when either body dies or they drift too far apart.
 * The client side (camera, keys) is client/MindTransferClient.
 */
public final class MindTransfer {
    private static final DustParticleOptions SPIRIT = new DustParticleOptions(new Vector3f(0.85f, 0.7f, 1.0f), 1.3f);
    private static final double WALK = 0.22, MAX_APART = 48;

    private static final class Link {
        final int targetId;
        final long until;
        float forward, strafe, yaw, pitch;
        boolean jump, sneak, attack;
        long lastAttack;

        Link(int targetId, long until, float yaw, float pitch) {
            this.targetId = targetId;
            this.until = until;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    private static final Map<UUID, Link> LINKS = new HashMap<>();
    /** Possessed creature (entity id) -> the caster inside it. */
    private static final Map<Integer, UUID> INSIDE = new HashMap<>();

    private MindTransfer() {}

    public static void start(ServerPlayer caster, LivingEntity target, int ticks) {
        end(caster);
        long now = caster.level().getGameTime();
        LINKS.put(caster.getUUID(), new Link(target.getId(), now + ticks, target.getYRot(), target.getXRot()));
        INSIDE.put(target.getId(), caster.getUUID());
        Afflictions.stun(caster, 10, Afflictions.STUN_NONE);
        Afflictions.stun(target, 10, Afflictions.STUN_NONE);
        if (target instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
        }
        ServerLevel level = caster.serverLevel();
        JutsuUtil.line(level, SPIRIT, caster.getEyePosition(), target.getEyePosition(), 0.35, 2, 0.02);
        JutsuUtil.sound(level, target.position(), SoundEvents.SOUL_ESCAPE, 1.2f, 1.2f);
        send(caster, target.getId(), ticks);
    }

    public static boolean isLinked(ServerPlayer caster) {
        return LINKS.containsKey(caster.getUUID());
    }

    /** The caster whose mind is in this creature, if any (for sharing its pain). */
    public static UUID casterInside(Entity body) {
        return INSIDE.get(body.getId());
    }

    /** The caster's mind returns to their body. */
    public static void end(ServerPlayer caster) {
        Link l = LINKS.remove(caster.getUUID());
        if (l == null) return;
        INSIDE.remove(l.targetId);
        send(caster, l.targetId, 0);
        Afflictions.unstun(caster);
        Entity e = caster.level().getEntity(l.targetId);
        if (e instanceof LivingEntity target) {
            Afflictions.unstun(target);
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));   // its own mind comes back, dizzy
            JutsuUtil.line(caster.serverLevel(), SPIRIT, target.getEyePosition(), caster.getEyePosition(), 0.35, 2, 0.02);
        }
        JutsuUtil.sound(caster.level(), caster.position(), SoundEvents.SOUL_ESCAPE, 1.0f, 0.8f);
    }

    private static void send(ServerPlayer caster, int targetId, int ticks) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> caster), new MindLinkPacket(caster.getId(), targetId, ticks));
    }

    /** The caster's keys and view, sent every tick while they're inside (MindInputPacket). */
    public static void input(ServerPlayer caster, float forward, float strafe, boolean jump, boolean sneak, boolean attack, float yaw, float pitch) {
        Link l = LINKS.get(caster.getUUID());
        if (l == null) return;
        l.forward = Mth.clamp(forward, -1f, 1f);
        l.strafe = Mth.clamp(strafe, -1f, 1f);
        l.jump = jump;
        l.sneak = sneak;
        l.attack |= attack;
        l.yaw = yaw;
        l.pitch = Mth.clamp(pitch, -90f, 90f);
    }

    /** Every tick for the caster (from the ninja ticker). */
    public static void tick(ServerPlayer caster) {
        Link l = LINKS.get(caster.getUUID());
        if (l == null) return;
        ServerLevel level = caster.serverLevel();
        long now = level.getGameTime();
        Entity e = level.getEntity(l.targetId);
        if (!(e instanceof LivingEntity body) || !body.isAlive() || !caster.isAlive() || now >= l.until || l.sneak
                || body.distanceToSqr(caster) > MAX_APART * MAX_APART) {
            end(caster);
            return;
        }
        Afflictions.stun(caster, 10, Afflictions.STUN_NONE);   // the empty body can't do anything
        Afflictions.stun(body, 10, Afflictions.STUN_NONE);     // and the body has no will of its own
        caster.setDeltaMovement(0, Math.min(0, caster.getDeltaMovement().y), 0);

        // turn and walk the borrowed body
        float yawRad = l.yaw * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yawRad), 0, Mth.cos(yawRad));
        Vec3 left = new Vec3(Mth.cos(yawRad), 0, Mth.sin(yawRad));
        Vec3 move = fwd.scale(l.forward).add(left.scale(l.strafe));
        if (move.lengthSqr() > 1) move = move.normalize();
        move = move.scale(WALK);
        if (body instanceof ServerPlayer tp) {
            Vec3 to = tp.position().add(move);
            AABB box = tp.getBoundingBox().move(move);
            if (!level.noCollision(tp, box)) to = tp.position();
            tp.connection.teleport(to.x, to.y, to.z, l.yaw, l.pitch);
        } else {
            body.setYRot(l.yaw);
            body.setYHeadRot(l.yaw);
            body.setYBodyRot(l.yaw);
            body.setXRot(l.pitch);
            if (body instanceof Mob mob) {
                mob.getNavigation().stop();
                mob.setTarget(null);
            }
            Vec3 v = body.getDeltaMovement();
            double y = v.y;
            if (l.jump && body.onGround()) y = 0.42;
            body.setDeltaMovement(move.x, y, move.z);
            body.hurtMarked = true;
        }

        // attacks: whatever the borrowed body is facing, within reach
        if (l.attack && now - l.lastAttack >= 10) {
            l.lastAttack = now;
            body.swing(InteractionHand.MAIN_HAND, true);
            Vec3 eye = body.getEyePosition();
            Vec3 look = Vec3.directionFromRotation(l.pitch, l.yaw);
            LivingEntity hit = null;
            double best = 9.0;
            for (LivingEntity c : level.getEntitiesOfClass(LivingEntity.class, body.getBoundingBox().inflate(3.5), c -> c != body && c != caster && c.isAlive())) {
                Vec3 to = c.getBoundingBox().getCenter().subtract(eye);
                double d = to.lengthSqr();
                if (d < best && to.normalize().dot(look) > 0.85) {
                    best = d;
                    hit = c;
                }
            }
            if (hit != null) {
                if (body instanceof Mob mob) mob.doHurtTarget(hit);
                else if (body instanceof ServerPlayer tp) tp.attack(hit);
                else hit.hurt(level.damageSources().mobAttack(body), 2f);
            }
        }
        l.attack = false;
    }

    /** The borrowed body was hurt: the caster's own body feels a share of it. */
    public static void shareDamage(LivingEntity body, float amount) {
        UUID id = INSIDE.get(body.getId());
        if (id == null || !(body.level() instanceof ServerLevel level)) return;
        ServerPlayer caster = level.getServer().getPlayerList().getPlayer(id);
        float share = (float) Config.d(Config.MIND_TRANSFER_SHARE);
        if (caster != null && share > 0 && amount > 0) {
            caster.invulnerableTime = 0;
            caster.hurt(caster.damageSources().magic(), amount * share);
        }
    }

    /** Forgets everything (server stopping). */
    public static void clearAll() {
        LINKS.clear();
        INSIDE.clear();
    }
}
