package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.shinobiarts.ninja.ChakraNature.BONE;
import static com.shinobiarts.ninja.ChakraNature.EARTH;
import static com.shinobiarts.ninja.ChakraNature.ICE;
import static com.shinobiarts.ninja.ChakraNature.SHADOW;
import static com.shinobiarts.ninja.ChakraNature.MIND;
import static com.shinobiarts.ninja.ChakraNature.GENTLE_FIST;
import static com.shinobiarts.ninja.ChakraNature.SPACE_TIME;
import static com.shinobiarts.ninja.ChakraNature.MAGNET;
import static com.shinobiarts.ninja.ChakraNature.MEDICAL;
import static com.shinobiarts.ninja.ChakraNature.RINNEGAN;
import static com.shinobiarts.ninja.ChakraNature.SEALING;
import static com.shinobiarts.ninja.ChakraNature.WOOD;
import static com.shinobiarts.ninja.ChakraNature.FIRE;
import static com.shinobiarts.ninja.ChakraNature.LIGHTNING;
import static com.shinobiarts.ninja.ChakraNature.NONE;
import static com.shinobiarts.ninja.ChakraNature.WATER;
import static com.shinobiarts.ninja.ChakraNature.WIND;
import static com.shinobiarts.ninja.ChakraNature.YIN_YANG;
import static com.shinobiarts.ninja.ChakraNature.LAVA;
import static com.shinobiarts.ninja.ChakraNature.STORM;
import static com.shinobiarts.ninja.ChakraNature.BOIL;
import static com.shinobiarts.ninja.ChakraNature.SCORCH;
import static com.shinobiarts.jutsu.JutsuRank.A;
import static com.shinobiarts.jutsu.JutsuRank.B;
import static com.shinobiarts.jutsu.JutsuRank.C;
import static com.shinobiarts.jutsu.JutsuRank.D;
import static com.shinobiarts.jutsu.JutsuRank.S;

/**
 * Every jutsu in the mod. To add one: register it here, implement its effect in {@link JutsuEffects},
 * then add its name, description and recipe to tools/make_resources.py and run it.
 * A jutsu goes into the slots of its nature's release; clan and non-elemental jutsu go into Ninjutsu.
 * Cooldowns are in ticks (20 ticks = 1 second).
 */
public final class Jutsus {
    private static final Map<String, Jutsu> BY_ID = new LinkedHashMap<>();
    private static final Collection<Jutsu> ALL = Collections.unmodifiableCollection(BY_ID.values());

    // Ranks follow the show where it gives one (Narutopedia / databooks); unranked jutsu are placed by strength.
    // Each jutsu's chakra cost, damage, cooldown and charge are in its own section of Jutsus.toml (the cooldowns here are the
    // defaults). Chakra costs default by rank: D 18%, C 22%, B 27%, A 33%, S 40% of max chakra.
    //                                       id                    nature     clan          rank cooldown needs eyes
    // Fire Release
    public static final Jutsu FIREBALL          = reg("fireball",          FIRE,      null,         C,    30,  false, JutsuEffects::fireball);
    public static final Jutsu PHOENIX_FLOWER    = reg("phoenix_flower",    FIRE,      null,         C,    40,  false, JutsuEffects::phoenixFlower);
    public static final Jutsu FIRE_ANNIHILATION = reg("fire_annihilation", FIRE,      null,         B,   120,  false, JutsuEffects::fireAnnihilation);
    public static final Jutsu HIDING_IN_ASH     = reg("hiding_in_ash",     FIRE,      null,         C,   240,  false, JutsuEffects::hidingInAsh);
    public static final Jutsu MAJESTIC_FLAME    = reg("majestic_destroyer_flame", FIRE, null,       S,   400,  false, JutsuEffects::majesticDestroyerFlame);
    // Water Release
    public static final Jutsu WATER_BULLET      = reg("water_bullet",      WATER,     null,         D,    15,  false, JutsuEffects::waterBullet);
    public static final Jutsu WATER_PRISON      = reg("water_prison",      WATER,     null,         C,   160,  false, JutsuEffects::waterPrison);
    public static final Jutsu WATER_CLONE       = reg("water_clone",       WATER,     null,         B,   300,  false, JutsuEffects::waterClone);
    public static final Jutsu WATER_SHARK       = reg("water_shark",       WATER,     null,         B,   140,  false, JutsuEffects::waterShark);
    public static final Jutsu WATER_DRAGON      = reg("water_dragon",      WATER,     null,         B,   100,  false, JutsuEffects::waterDragon);
    // Wind Release
    public static final Jutsu GALE_PALM         = reg("gale_palm",         WIND,      null,         C,    20,  false, JutsuEffects::galePalm);
    public static final Jutsu VACUUM_BLADE      = reg("vacuum_blade",      WIND,      null,         B,    30,  false, JutsuEffects::vacuumBlade);
    public static final Jutsu GREAT_BREAKTHROUGH= reg("great_breakthrough",WIND,      null,         C,   100,  false, JutsuEffects::greatBreakthrough);
    public static final Jutsu RASENSHURIKEN     = reg("rasenshuriken",     WIND,      null,         S,   300,  false, JutsuEffects::rasenshuriken);
    // Lightning Release
    public static final Jutsu LIGHTNING_ARMOR   = reg("lightning_armor",   LIGHTNING, null,         A,   480,  false, JutsuEffects::lightningArmor);
    public static final Jutsu CHIDORI           = reg("chidori",           LIGHTNING, null,         A,    80,  false, JutsuEffects::chidori);
    // Earth Release
    public static final Jutsu EARTH_WALL        = reg("earth_wall",        EARTH,     null,         B,   100,  false, JutsuEffects::earthWall);
    public static final Jutsu ROCK_ARMOR        = reg("rock_armor",        EARTH,     null,         B,   480,  false, JutsuEffects::rockArmor);
    public static final Jutsu EARTH_SPIKES      = reg("earth_spikes",      EARTH,     null,         B,    50,  false, JutsuEffects::earthSpikes);
    // Yin Yang Release: Yin illusions (stronger with Genjutsu) and Yang healing (stronger with Medical)
    public static final Jutsu HELL_VIEWING      = reg("hell_viewing",      YIN_YANG,       null,         D,   100,  false, JutsuEffects::hellViewing);
    public static final Jutsu MIND_FOG          = reg("mind_fog",          YIN_YANG,       null,         C,   200,  false, JutsuEffects::mindFog);
    public static final Jutsu YIN_BLADES        = reg("yin_blades",        YIN_YANG,      null,         A,   160,  false, YinYangJutsu::yinBlades);
    public static final Jutsu YANG_BURST        = reg("yang_burst",        YIN_YANG,      null,         S,   600,  false, YinYangJutsu::yangBurst);
    // Non-elemental (Ninjutsu release)
    public static final Jutsu SUBSTITUTION      = reg("substitution",      NONE,      null,         D,  1200,  false, JutsuEffects::substitution);
    public static final Jutsu BODY_FLICKER      = reg("body_flicker",      NONE,      null,         D,    30,  false, JutsuEffects::bodyFlicker);
    public static final Jutsu SHADOW_CLONE      = reg("shadow_clone",      NONE,      null,         B,   200,  false, JutsuEffects::shadowClone);
    public static final Jutsu MULTI_SHADOW_CLONE= reg("multi_shadow_clone",NONE,      null,         A,   600,  false, JutsuEffects::multiShadowClone);
    public static final Jutsu RASENGAN          = reg("rasengan",          NONE,      null,         A,   100,  false, JutsuEffects::rasengan);
    // Clan techniques. (Amaterasu is no longer a scroll: it's Jutsu 1 of the Itachi, Sasuke and Eternal Mangekyou.)
    public static final Jutsu SHADOW_POSSESSION = reg("shadow_possession", SHADOW,    null,    C,   180,  false, JutsuEffects::shadowPossession);
    public static final Jutsu MIND_TRANSFER     = reg("mind_body_transfer", MIND,     null, B,  600,  false, JutsuEffects::mindBodyTransfer);
    public static final Jutsu PALM_ROTATION     = reg("palm_rotation",     GENTLE_FIST, null,   A,   100,  false, JutsuEffects::palmRotation);

    // Clan releases: only their clan can learn them (the clan comes from the release). The first of each is given
    // with the release when the clan is locked in; the other two are scrolls. Effects are in ClanJutsu.
    // Wood Release (Senju)
    public static final Jutsu WOOD_BINDING      = reg("wood_binding",      WOOD,      null,         C,   200,  false, ClanJutsu::woodBinding);
    public static final Jutsu WOOD_DOME         = reg("wood_dome",         WOOD,      null,         B,   600,  false, ClanJutsu::woodDome);
    public static final Jutsu DEEP_FOREST       = reg("deep_forest",       WOOD,      null,         S,  1200,  false, ClanJutsu::deepForest);
    // Ice Release (Yuki)
    public static final Jutsu ICE_NEEDLES       = reg("ice_needles",       ICE,       null,         C,    40,  false, ClanJutsu::iceNeedles);
    public static final Jutsu ICE_PRISON        = reg("ice_prison",        ICE,       null,         B,   240,  false, ClanJutsu::icePrison);
    public static final Jutsu ICE_MIRRORS       = reg("ice_mirrors",       ICE,       null,         A,   600,  false, ClanJutsu::iceMirrors);
    // Magnet Release (Kazekage)
    public static final Jutsu IRON_SAND_DRIZZLE = reg("iron_sand_drizzle", MAGNET,    null,         C,    60,  false, ClanJutsu::ironSandDrizzle);
    public static final Jutsu IRON_SAND_COFFIN  = reg("iron_sand_coffin",  MAGNET,    null,         B,   240,  false, ClanJutsu::ironSandCoffin);
    public static final Jutsu IRON_SAND_WORLD   = reg("iron_sand_world",   MAGNET,    null,         A,   400,  false, ClanJutsu::ironSandWorld);
    // Bone (Kaguya)
    public static final Jutsu FINGER_BULLETS    = reg("finger_bullets",    BONE,      null,         C,    40,  false, ClanJutsu::fingerBullets);
    public static final Jutsu WILLOW_DANCE      = reg("willow_dance",      BONE,      null,         B,   600,  false, ClanJutsu::willowDance);
    public static final Jutsu SEEDLING_FERN     = reg("seedling_fern",     BONE,      null,         A,   600,  false, ClanJutsu::seedlingFern);
    // Sealing (Uzumaki)
    public static final Jutsu BARRIER           = reg("barrier",           SEALING,   null,         C,   400,  false, ClanJutsu::barrier);
    public static final Jutsu ADAMANTINE_CHAINS = reg("adamantine_chains", SEALING,   null,         B,   300,  false, ClanJutsu::adamantineChains);
    public static final Jutsu FIVE_ELEMENTS_SEAL= reg("five_elements_seal",SEALING,   null,         A,   900,  false, ClanJutsu::fiveElementsSeal);

    // More jutsu from the show (effects in MoreJutsu)
    public static final Jutsu GREAT_DRAGON_FIRE = reg("great_dragon_fire", FIRE,      null,         A,   500,  false, MoreJutsu::greatDragonFire);
    public static final Jutsu HIDING_IN_MIST    = reg("hiding_in_mist",    WATER,     null,         C,   600,  false, MoreJutsu::hidingInMist);
    public static final Jutsu VACUUM_SPHERE     = reg("vacuum_sphere",     WIND,      null,         C,   140,  false, MoreJutsu::vacuumSphere);
    public static final Jutsu VACUUM_GREAT_SPHERE = reg("vacuum_great_sphere", WIND,  null,         A,   420,  false, MoreJutsu::vacuumGreatSphere);
    public static final Jutsu GREAT_SICKLE_WEASEL = reg("great_sickle_weasel", WIND,  null,         A,   450,  false, MoreJutsu::greatSickleWeasel);
    public static final Jutsu KIRIN             = reg("kirin",             LIGHTNING, null,         S,  1200,  false, MoreJutsu::kirin);
    public static final Jutsu BLACK_PANTHER     = reg("black_panther",     LIGHTNING, null,         A,   380,  false, MoreJutsu::blackPanther);
    public static final Jutsu FALSE_DARKNESS    = reg("false_darkness",    LIGHTNING, null,         B,   300,  false, MoreJutsu::falseDarkness);
    public static final Jutsu LIGHTNING_BEAST   = reg("lightning_beast_running", LIGHTNING, null,   B,   300,  false, MoreJutsu::lightningBeast);
    public static final Jutsu EARTH_SPEAR       = reg("earth_spear",       EARTH,     null,         B,   260,  false, MoreJutsu::earthSpear);
    public static final Jutsu HIDING_LIKE_A_MOLE = reg("hiding_like_a_mole", EARTH,   null,         C,   300,  false, MoreJutsu::hidingLikeAMole);
    public static final Jutsu EARTH_DRAGON_BULLET = reg("earth_dragon_bullet", EARTH, null,         B,   320,  false, MoreJutsu::earthDragonBullet);
    public static final Jutsu EARTH_SANDWICH    = reg("earth_sandwich",    EARTH,     null,         A,   400,  false, MoreJutsu::earthSandwich);
    public static final Jutsu ROCK_GOLEM        = reg("rock_golem",        EARTH,     null,         S,  1200,  false, MoreJutsu::rockGolem);

    // Advanced natures (kekkei genkai of two elements, from DNA or a scroll). Effects are in AdvancedJutsu.
    // Lava Release (Fire + Earth)
    public static final Jutsu SCORCHING_STREAM_ROCK = reg("scorching_stream_rock", LAVA,  null,         C,    60,  false, AdvancedJutsu::scorchingStreamRock);
    public static final Jutsu QUICKLIME_CONGEALING = reg("quicklime_congealing", LAVA,    null,         B,   240,  false, AdvancedJutsu::quicklimeCongealing);
    public static final Jutsu MELTING_APPARITION = reg("melting_apparition", LAVA,        null,         A,   400,  false, AdvancedJutsu::meltingApparition);
    // Storm Release (Lightning + Water)
    public static final Jutsu STORM_CLOUD       = reg("storm_cloud",       STORM,     null,         B,   300,  false, AdvancedJutsu::stormCloud);
    public static final Jutsu LASER_CIRCUS      = reg("laser_circus",      STORM,     null,         A,   300,  false, AdvancedJutsu::laserCircus);
    // Boil Release (Fire + Water)
    public static final Jutsu SKILLED_MIST      = reg("skilled_mist",      BOIL,      null,         B,   300,  false, AdvancedJutsu::skilledMist);
    public static final Jutsu UNRIVALLED_STRENGTH = reg("unrivalled_strength", BOIL,    null,         A,   600,  false, AdvancedJutsu::unrivalledStrength);
    // Scorch Release (Fire + Wind)
    public static final Jutsu SCORCHING_SUN     = reg("scorching_sun",     SCORCH,    null,         C,    60,  false, AdvancedJutsu::scorchingSun);
    public static final Jutsu EXTREMELY_STEAMING_MURDER = reg("extremely_steaming_murder", SCORCH, null, A, 500, false, AdvancedJutsu::extremelySteamingMurder);

    // Medical Release (everyone's): learned from scrolls. Effects are in MedicalJutsu.
    public static final Jutsu HEALING_JUTSU     = reg("healing_jutsu",     MEDICAL,   null,         C,   160,  false, MedicalJutsu::healingJutsu);
    public static final Jutsu POISON_MIST       = reg("poison_mist",       MEDICAL,   null,         B,   240,  false, MedicalJutsu::poisonMist);
    public static final Jutsu CELLULAR_ACTIVATION = reg("cellular_activation", MEDICAL, null,       A,   900,  false, MedicalJutsu::cellularActivation);

    // Rinnegan (the Sage of Six Paths' eyes: the Hagoromo and Otsutsuki clans, or awakened from DNA). Taught with the
    // eyes; nobody else can learn them. Effects are in RinneganJutsu.
    public static final Jutsu SHINRA_TENSEI     = reg("shinra_tensei",     RINNEGAN,     null,         S,   300,  false, RinneganJutsu::shinraTensei);
    public static final Jutsu BANSHO_TENIN      = reg("bansho_tenin",      RINNEGAN,     null,         A,   160,  false, RinneganJutsu::banshoTenin);
    public static final Jutsu CHIBAKU_TENSEI    = reg("chibaku_tensei",    RINNEGAN,     null,         S,  1200,  false, RinneganJutsu::chibakuTensei);
    public static final Jutsu FLYING_THUNDER_GOD = reg("flying_thunder_god", NONE,       null,         A,   200,  false, MoreJutsu::flyingThunderGod);
    public static final Jutsu FTG_STRIKE        = reg("ftg_strike",        SPACE_TIME,   null,         A,   160,  false, MoreJutsu::ftgStrike);
    public static final Jutsu EDO_TENSEI        = reg("edo_tensei",        NONE,         null,         S,  2400,  false, EdoTenseiJutsu::cast);
    public static final Jutsu TENGAI_SHINSEI    = reg("tengai_shinsei",    RINNEGAN,     null,         S,  1800,  false, RinneganJutsu::tengaiShinsei);

    /**
     * Whether the jutsu has a scroll. Kekkei genkai jutsu (Wood, Ice, Magnet, Bone, Sealing and the Rinnegan's) don't:
     * they come with the kekkei genkai itself (clan, DNA).
     */
    public static boolean hasScroll(Jutsu jutsu) {
        return !jutsu.nature().isKekkeiGenkai();
    }

    /** The Rinnegan's jutsu. */
    public static boolean isRinnegan(Jutsu jutsu) {
        return jutsu == SHINRA_TENSEI || jutsu == BANSHO_TENIN || jutsu == CHIBAKU_TENSEI || jutsu == TENGAI_SHINSEI;
    }

    private static Jutsu reg(String id, ChakraNature nature, @Nullable Clan clan, JutsuRank rank, int cooldown, boolean needsDojutsu, Jutsu.Action action) {
        Jutsu jutsu = new Jutsu(id, nature, clan, rank, cooldown, needsDojutsu, action);
        if (BY_ID.put(id, jutsu) != null) throw new IllegalStateException("Duplicate jutsu id " + id);
        return jutsu;
    }

    @Nullable
    public static Jutsu get(String id) {
        return BY_ID.get(id);
    }

    public static Collection<Jutsu> all() {
        return ALL;
    }

    /** The first jutsu of a release (the one a clan release starts with), or null. */
    @Nullable
    public static Jutsu firstOf(ChakraNature release) {
        for (Jutsu j : ALL) {
            if (j.nature() == release) return j;
        }
        return null;
    }

    /** Jutsu that deal damage: the ones Jutsu Points can upgrade. */
    private static final java.util.Set<String> DAMAGING = java.util.Set.of(
            "fireball", "phoenix_flower", "hiding_in_ash", "fire_annihilation", "majestic_destroyer_flame", "water_bullet", "water_prison", "water_shark", "water_dragon",
            "gale_palm", "vacuum_blade", "great_breakthrough", "rasenshuriken", "chidori",
            "earth_spikes", "hell_viewing", "rasengan", "palm_rotation", "yin_blades", "yang_burst",
            "deep_forest", "ice_needles", "ice_mirrors", "iron_sand_drizzle", "iron_sand_coffin", "iron_sand_world",
            "finger_bullets", "seedling_fern", "poison_mist", "great_dragon_fire", "vacuum_sphere", "vacuum_great_sphere",
            "great_sickle_weasel", "kirin", "black_panther", "false_darkness", "lightning_beast_running", "earth_spear",
            "hiding_like_a_mole", "earth_dragon_bullet", "earth_sandwich", "rock_golem",
            "scorching_stream_rock", "quicklime_congealing", "melting_apparition", "storm_cloud", "laser_circus", "skilled_mist",
            "scorching_sun", "extremely_steaming_murder");

    public static boolean upgradeable(Jutsu jutsu) {
        return DAMAGING.contains(jutsu.id());
    }

    /** Position in registration order: how the client names a jutsu in packets (same on both sides). */
    public static int index(Jutsu jutsu) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (j == jutsu) return i;
            i++;
        }
        return -1;
    }

    @Nullable
    public static Jutsu byIndex(int index) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (i++ == index) return j;
        }
        return null;
    }

    private Jutsus() {}
}
