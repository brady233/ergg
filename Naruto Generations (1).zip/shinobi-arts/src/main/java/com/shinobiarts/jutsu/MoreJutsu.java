package com.shinobiarts.jutsu;

import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * More jutsu from the show:
 * <ul>
 *   <li>Fire: Great Dragon Fire Technique.</li>
 *   <li>Wind: Vacuum Sphere, Vacuum Great Sphere, Vacuum Great Sickle Weasel.</li>
 *   <li>Lightning: Kirin, Black Panther, False Darkness, Lightning Beast Running Technique.</li>
 *   <li>Earth: Earth Spear, Hiding Like a Mole, Earth Dragon Bullet, Earth Sandwich, Rock Golem.</li>
 *   <li>Water: Hiding in Mist.</li>
 * </ul>
 * Most of them are a shape that travels (see {@link #travel}); the client draws the same path from the Fx it's sent.
 */
public final class MoreJutsu {
    private static final DustParticleOptions WIND_DUST = new DustParticleOptions(new Vector3f(0.85f, 0.95f, 1.0f), 1.6f);
    private static final DustParticleOptions BOLT_DUST = new DustParticleOptions(new Vector3f(0.75f, 0.85f, 1.0f), 1.2f);
    private static final DustParticleOptions BLACK_DUST = new DustParticleOptions(new Vector3f(0.08f, 0.06f, 0.1f), 1.6f);
    private static final DustParticleOptions MUD_DUST = new DustParticleOptions(new Vector3f(0.42f, 0.3f, 0.18f), 1.8f);

    private MoreJutsu() {}

    // ================================================================ helpers

    /** Where the player aims, up to {@code range} blocks (a block, or the end of the line). */
    private static Vec3 aim(ServerPlayer p, double range) {
        BlockHitResult hit = JutsuUtil.rayBlock(p, range);
        return hit.getType() == HitResult.Type.MISS ? p.getEyePosition().add(p.getLookAngle().scale(range)) : hit.getLocation();
    }

    /** The top of the ground at or below {@code at} (searching a few blocks up and down). */
    static double groundY(ServerLevel level, Vec3 at) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int x = (int) Math.floor(at.x), z = (int) Math.floor(at.z), y0 = (int) Math.floor(at.y);
        for (int dy = 3; dy >= -8; dy--) {
            pos.set(x, y0 + dy - 1, z);
            if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty() && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()) {
                return y0 + dy;
            }
        }
        return at.y;
    }

    /**
     * Moves a jutsu from {@code from} to {@code to} (or onto {@code homing}, chasing it) at {@code speed} blocks a tick.
     * Every creature within {@code radius} it touches is passed to {@code hit} once; if it doesn't {@code pierce} it
     * stops at the first. {@code end} gets where it stopped. Returns how many ticks the trip takes at most.
     */
    static int travel(ServerLevel level, ServerPlayer caster, Vec3 from, Vec3 to, @Nullable LivingEntity homing, double speed,
                      double radius, boolean pierce, boolean hugGround, BiConsumer<LivingEntity, Vec3> hit, @Nullable Consumer<Vec3> end,
                      @Nullable Consumer<Vec3> step) {
        double dist = homing != null ? from.distanceTo(homing.getBoundingBox().getCenter()) : from.distanceTo(to);
        int ticks = Math.max(2, Math.min(80, (int) Math.ceil(dist / speed)));
        Set<Integer> struck = new HashSet<>();
        boolean[] done = {false};
        Scheduler.repeat(0, 1, ticks, i -> {
            if (done[0]) return;
            float t = (i + 1) / (float) ticks;
            Vec3 goal = homing != null && homing.isAlive() ? homing.getBoundingBox().getCenter() : to;
            Vec3 at = from.lerp(goal, t);
            if (hugGround) at = new Vec3(at.x, groundY(level, at) + 0.6, at.z);
            if (step != null) step.accept(at);
            for (LivingEntity e : JutsuUtil.inRadius(level, caster, at, radius)) {
                if (e == caster || !struck.add(e.getId())) continue;
                hit.accept(e, at);
                if (!pierce) {
                    done[0] = true;
                    if (end != null) end.accept(at);
                    return;
                }
            }
            if (i == ticks - 1) {
                done[0] = true;
                if (end != null) end.accept(at);
            }
        });
        return ticks;
    }

    private static void hurt(ServerLevel level, ServerPlayer p, LivingEntity e, float amount) {
        e.invulnerableTime = 0;
        e.hurt(ModDamage.jutsu(level, null, p), amount);
    }

    private static Vec3 away(Vec3 from, LivingEntity e) {
        Vec3 d = e.position().subtract(from);
        d = new Vec3(d.x, 0, d.z);
        return d.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : d.normalize();
    }

    private static Vec3 flatLook(ServerPlayer p) {
        Vec3 l = p.getLookAngle();
        Vec3 f = new Vec3(l.x, 0, l.z);
        return f.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : f.normalize();
    }

    private static Vec3 mouth(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.6)).subtract(0, 0.25, 0);
    }

    // ================================================================ fire

    /** Great Dragon Fire Technique: a dragon of fire roars out and flies at the target, then bursts into flame. */
    public static boolean greatDragonFire(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 from = mouth(p);
        LivingEntity target = JutsuUtil.rayTarget(p, 40);
        Vec3 to = target != null ? target.getBoundingBox().getCenter() : aim(p, 40);
        float body = JutsuUtil.dmg(16f), blast = JutsuUtil.dmg(10f);
        int ticks = travel(level, p, from, to, target, 1.2, 2.4, true, false, (e, at) -> {
            hurt(level, p, e, body);
            e.setSecondsOnFire(8);
            JutsuUtil.push(e, away(at, e).scale(0.8).add(0, 0.4, 0));
        }, end -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, end, 5)) {
                hurt(level, p, e, blast);
                e.setSecondsOnFire(8);
            }
            level.sendParticles(ParticleTypes.FLAME, end.x, end.y, end.z, 160, 2.5, 1.5, 2.5, 0.15);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
            JutsuUtil.sound(level, end, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.6f);
            JutsuUtil.sound(level, end, SoundEvents.BLAZE_SHOOT, 2.0f, 0.5f);
        }, at -> level.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 10, 0.8, 0.8, 0.8, 0.03));
        Fx.send(level, Fx.Visual.FIRE_DRAGON, from, to, -1, target == null ? -1 : target.getId(), 1f, ticks + 10);
        JutsuUtil.sound(level, from, SoundEvents.ENDER_DRAGON_GROWL, 1.2f, 1.3f);
        JutsuUtil.sound(level, from, SoundEvents.BLAZE_SHOOT, 2.0f, 0.4f);
        return true;
    }

    // ================================================================ wind

    /** Vacuum Sphere: a rapid volley of five compressed bullets of air, spat one after another. */
    public static boolean vacuumSphere(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        float dmg = JutsuUtil.dmg(4f);
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        for (int k = 0; k < 5; k++) {
            int shot = k;
            Scheduler.later(k * 3, () -> {
                if (!p.isAlive()) return;
                Vec3 from = mouth(p);
                Vec3 spread = new Vec3(level.random.nextGaussian(), level.random.nextGaussian() * 0.5, level.random.nextGaussian()).scale(0.04);
                Vec3 dir = p.getLookAngle().add(spread).normalize();
                Vec3 to = from.add(dir.scale(30));
                BlockHitResult wall = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                if (wall.getType() != HitResult.Type.MISS) to = wall.getLocation();
                Vec3 end = to;
                int ticks = travel(level, p, from, end, null, 2.2, 0.9, false, false, (e, at) -> {
                    hurt(level, p, e, dmg);
                    JutsuUtil.push(e, dir.scale(0.6).add(0, 0.15, 0));
                }, at -> level.sendParticles(ParticleTypes.POOF, at.x, at.y, at.z, 6, 0.2, 0.2, 0.2, 0.05), null);
                Fx.send(level, Fx.Visual.WIND_BULLET, from, end, -1, -1, 0.55f, ticks + 2);
                JutsuUtil.sound(level, from, SoundEvents.PHANTOM_FLAP, 0.9f, 1.8f + shot * 0.05f);
            });
        }
        return true;
    }

    /** Vacuum Great Sphere: one huge ball of compressed air that slams down everything where it bursts. */
    public static boolean vacuumGreatSphere(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 from = mouth(p);
        LivingEntity target = JutsuUtil.rayTarget(p, 36);
        Vec3 to = target != null ? target.getBoundingBox().getCenter() : aim(p, 36);
        float blast = JutsuUtil.dmg(14f);
        int ticks = travel(level, p, from, to, target, 1.3, 1.8, false, false, (e, at) -> {}, end -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, end, 5)) {
                hurt(level, p, e, blast);
                JutsuUtil.push(e, away(end, e).scale(1.8).add(0, 0.7, 0));
            }
            Fx.at(level, Fx.Visual.SHINRA, end, 5f, 12);
            level.sendParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 6, 2, 1, 2, 0);
            level.sendParticles(WIND_DUST, end.x, end.y, end.z, 120, 3, 2, 3, 0.1);
            JutsuUtil.sound(level, end, SoundEvents.GENERIC_EXPLODE, 2.0f, 1.1f);
            JutsuUtil.sound(level, end, SoundEvents.ELYTRA_FLYING, 1.2f, 1.6f);
        }, null);
        Fx.send(level, Fx.Visual.WIND_BULLET, from, to, -1, target == null ? -1 : target.getId(), 1.9f, ticks + 2);
        JutsuUtil.sound(level, from, SoundEvents.ENDER_DRAGON_SHOOT, 1.0f, 1.6f);
        return true;
    }

    /**
     * Vacuum Great Sickle Weasel (Temari): one great swing sends a storm of cutting wind sweeping forward 26 blocks in
     * a band 12 wide, slicing everything again and again and blowing it away.
     */
    public static boolean greatSickleWeasel(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 fwd = flatLook(p);
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3 origin = p.position().add(0, 1, 0);
        float cut = JutsuUtil.dmg(5f);
        double reach = 26, width = 12;
        int ticks = 22;
        Fx.line(level, Fx.Visual.SICKLE_WEASEL, origin, origin.add(fwd.scale(reach)), (float) width, ticks + 6);
        Scheduler.repeat(0, 1, ticks, i -> {
            double front = 2 + (reach - 2) * (i + 1) / ticks;
            Vec3 c = origin.add(fwd.scale(front - 2));
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, width * 0.6)) {
                Vec3 rel = e.position().subtract(origin);
                double along = rel.dot(fwd), across = Math.abs(rel.dot(right));
                if (along < 0 || along > front + 1 || across > width / 2) continue;
                if (i % 4 == 0) hurt(level, p, e, cut);
                e.setDeltaMovement(e.getDeltaMovement().add(fwd.scale(0.35)).add(0, 0.08, 0));
                e.hurtMarked = true;
            }
            for (int k = -3; k <= 3; k++) {
                Vec3 at = origin.add(fwd.scale(front)).add(right.scale(k * width / 7));
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y + 0.5, at.z, 1, 0.3, 0.6, 0.3, 0);
            }
            if (i % 5 == 0) JutsuUtil.sound(level, origin.add(fwd.scale(front)), SoundEvents.PLAYER_ATTACK_SWEEP, 1.4f, 0.6f);
        });
        JutsuUtil.sound(level, origin, SoundEvents.ELYTRA_FLYING, 2.0f, 1.3f);
        JutsuUtil.sound(level, origin, SoundEvents.TRIDENT_RIPTIDE_3, 1.5f, 1.2f);
        return true;
    }

    // ================================================================ lightning

    /**
     * Kirin: storm clouds gather over where you look; a moment later a dragon of lightning comes down out of them on
     * that spot, a huge, unavoidable strike.
     */
    public static boolean kirin(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 50);
        Vec3 aimAt = target != null ? target.position() : aim(p, 50);
        Vec3 ground = new Vec3(aimAt.x, groundY(level, aimAt), aimAt.z);
        float strike = JutsuUtil.dmg(30f);
        Fx.at(level, Fx.Visual.KIRIN, ground, 1f, 70);
        JutsuUtil.sound(level, ground, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.5f, 0.6f);
        Scheduler.later(38, () -> {                                    // the giant dragon reaches the ground
            Vec3 at = target != null && target.isAlive() ? target.position() : ground;
            net.minecraft.world.entity.LightningBolt bolt = net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(at.x, at.y, at.z);
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
            for (LivingEntity e : JutsuUtil.inRadius(level, p, at, 12)) {
                hurt(level, p, e, strike);
                Afflictions.stun(e, 40, Afflictions.STUN_NONE);
                JutsuUtil.push(e, away(at, e).scale(0.8).add(0, 0.6, 0));
            }
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y + 0.5, at.z, 2, 1, 0.5, 1, 0);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 1, at.z, 500, 10, 4, 10, 0.8);
            if (JutsuUtil.griefing(level, p)) level.explode(null, at.x, at.y, at.z, 6f, net.minecraft.world.level.Level.ExplosionInteraction.TNT);
            JutsuUtil.sound(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 3.0f, 0.5f);
            JutsuUtil.sound(level, at, SoundEvents.ENDER_DRAGON_GROWL, 2.0f, 1.4f);
            JutsuUtil.sound(level, at, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.6f);
        });
        return true;
    }

    /** Black Panther (Darui): a panther of black lightning bounds along the ground after the target and paralyses it. */
    public static boolean blackPanther(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        Vec3 from = p.position().add(flatLook(p).scale(1.2)).add(0, 0.6, 0);
        Vec3 to = target != null ? target.position() : aim(p, 32);
        float dmg = JutsuUtil.dmg(14f);
        int ticks = travel(level, p, from, to, target, 1.0, 1.4, false, true, (e, at) -> {
            hurt(level, p, e, dmg);
            Afflictions.stun(e, 50, Afflictions.STUN_NONE);
            level.sendParticles(BLACK_DUST, at.x, at.y + 0.5, at.z, 50, 0.6, 0.8, 0.6, 0.0);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 0.5, at.z, 40, 0.6, 0.8, 0.6, 0.3);
            JutsuUtil.sound(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.0f, 1.4f);
        }, null, at -> level.sendParticles(BLACK_DUST, at.x, at.y, at.z, 4, 0.4, 0.3, 0.4, 0.0));
        Fx.send(level, Fx.Visual.BLACK_PANTHER, from, to, -1, target == null ? -1 : target.getId(), 1f, ticks + 4);
        JutsuUtil.sound(level, from, SoundEvents.RAVAGER_ROAR, 0.8f, 1.6f);
        JutsuUtil.sound(level, from, SoundEvents.BEACON_POWER_SELECT, 1.0f, 0.5f);
        return true;
    }

    /** False Darkness (Kakuzu): a spear of lightning fired from the mouth, piercing everything in a line. */
    public static boolean falseDarkness(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 from = mouth(p);
        Vec3 to = aim(p, 34);
        float dmg = JutsuUtil.dmg(12f);
        Fx.line(level, Fx.Visual.FALSE_DARKNESS, from, to, 1f, 16);
        JutsuUtil.sound(level, from, SoundEvents.BEACON_ACTIVATE, 1.0f, 2.0f);
        Scheduler.later(5, () -> {
            Vec3 dir = to.subtract(from);
            double len = dir.length();
            dir = dir.scale(1 / Math.max(1e-4, len));
            Set<Integer> struck = new HashSet<>();
            for (double s = 0; s <= len; s += 1.0) {
                Vec3 at = from.add(dir.scale(s));
                for (LivingEntity e : JutsuUtil.inRadius(level, p, at, 1.1)) {
                    if (e == p || !struck.add(e.getId())) continue;
                    hurt(level, p, e, dmg);
                    Afflictions.stun(e, 15, Afflictions.STUN_NONE);
                }
                if (((int) s) % 3 == 0) level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 3, 0.2, 0.2, 0.2, 0.2);
            }
            JutsuUtil.sound(level, from, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.5f, 1.6f);
            JutsuUtil.sound(level, to, SoundEvents.TRIDENT_THUNDER, 1.2f, 1.2f);
        });
        return true;
    }

    /** Lightning Beast Running Technique (Kakashi): a hound of lightning runs along the ground at the target. */
    public static boolean lightningBeast(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        Vec3 from = p.position().add(flatLook(p).scale(1.2)).add(0, 0.6, 0);
        Vec3 to = target != null ? target.position() : aim(p, 32);
        float dmg = JutsuUtil.dmg(11f);
        int ticks = travel(level, p, from, to, target, 1.4, 1.2, false, true, (e, at) -> {
            hurt(level, p, e, dmg);
            Afflictions.stun(e, 30, Afflictions.STUN_NONE);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 0.5, at.z, 50, 0.6, 0.8, 0.6, 0.4);
            JutsuUtil.sound(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 0.9f, 1.6f);
        }, null, at -> level.sendParticles(BOLT_DUST, at.x, at.y, at.z, 3, 0.3, 0.2, 0.3, 0.0));
        Fx.send(level, Fx.Visual.LIGHTNING_HOUND, from, to, -1, target == null ? -1 : target.getId(), 1f, ticks + 4);
        JutsuUtil.sound(level, from, SoundEvents.WOLF_GROWL, 1.0f, 1.3f);
        JutsuUtil.sound(level, from, SoundEvents.BEACON_ACTIVATE, 0.8f, 2.0f);
        return true;
    }

    // ================================================================ earth

    /** Earth Spear: the ground cracks under the target, then a great spear of stone bursts up through it. */
    public static boolean earthSpear(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        Vec3 aimAt = target != null ? target.position() : aim(p, 24);
        Vec3 ground = new Vec3(aimAt.x, groundY(level, aimAt), aimAt.z);
        float dmg = JutsuUtil.dmg(13f);
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        Fx.at(level, Fx.Visual.EARTH_SPEAR, ground, 1f, 60);
        level.sendParticles(stone, ground.x, ground.y + 0.1, ground.z, 30, 0.8, 0.05, 0.8, 0.05);
        JutsuUtil.sound(level, ground, SoundEvents.GRAVEL_BREAK, 1.5f, 0.5f);
        Scheduler.later(10, () -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, ground.add(0, 1, 0), 1.8)) {
                hurt(level, p, e, dmg);
                JutsuUtil.push(e, new Vec3(0, 1.1, 0));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            }
            level.sendParticles(stone, ground.x, ground.y + 1, ground.z, 80, 0.6, 1.5, 0.6, 0.2);
            JutsuUtil.sound(level, ground, SoundEvents.STONE_BREAK, 2.0f, 0.4f);
            JutsuUtil.sound(level, ground, SoundEvents.TRIDENT_HIT, 1.5f, 0.5f);
        });
        return true;
    }

    /**
     * Hiding Like a Mole (Headhunter): you dive into the ground and vanish, come up beneath the target and drag them
     * down into the earth up to their neck, stuck, then climb out behind them.
     */
    public static boolean hidingLikeAMole(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.no_target")
                    .withStyle(net.minecraft.ChatFormatting.GRAY), true);
            return false;
        }
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
        Vec3 start = p.position();
        level.sendParticles(dirt, start.x, start.y + 0.2, start.z, 60, 0.5, 0.3, 0.5, 0.2);
        JutsuUtil.sound(level, start, SoundEvents.ROOTED_DIRT_BREAK, 1.5f, 0.6f);
        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 22, 0, false, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 22, 4, false, false, false));
        Afflictions.stun(p, 16, Afflictions.STUN_NONE);
        float dmg = JutsuUtil.dmg(6f);
        Scheduler.later(16, () -> {
            if (!target.isAlive() || !p.isAlive()) return;
            Vec3 t = target.position();
            level.sendParticles(dirt, t.x, t.y + 0.3, t.z, 80, 0.5, 0.4, 0.5, 0.25);
            // pulled down into the ground up to the neck
            Vec3 sunk = t.subtract(0, Math.max(0.6, target.getBbHeight() - 0.6), 0);
            JutsuUtil.teleport(target, sunk);
            target.setDeltaMovement(Vec3.ZERO);
            hurt(level, p, target, dmg);
            Afflictions.stun(target, 80, Afflictions.STUN_NONE);
            Scheduler.later(80, () -> {                                // they dig themselves out
                if (target.isAlive()) JutsuUtil.teleport(target, JutsuUtil.findSafe(target, t) != null ? JutsuUtil.findSafe(target, t) : t);
            });
            // you come up behind them
            Vec3 behind = t.subtract(Vec3.directionFromRotation(0, target.getYRot()).scale(1.6));
            Vec3 safe = JutsuUtil.findSafe(p, behind);
            if (safe != null) JutsuUtil.teleport(p, safe);
            p.removeEffect(MobEffects.INVISIBILITY);
            level.sendParticles(dirt, p.getX(), p.getY() + 0.3, p.getZ(), 50, 0.4, 0.4, 0.4, 0.2);
            JutsuUtil.sound(level, t, SoundEvents.ROOTED_DIRT_BREAK, 2.0f, 0.5f);
            JutsuUtil.sound(level, t, SoundEvents.GRAVEL_BREAK, 2.0f, 0.4f);
        });
        return true;
    }

    /**
     * Earth Dragon Bullet: a dragon's head of earth rears up out of the ground in front of you and spits four balls of
     * mud at the target.
     */
    public static boolean earthDragonBullet(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 fwd = flatLook(p);
        Vec3 headBase = p.position().add(fwd.scale(2.5));
        headBase = new Vec3(headBase.x, groundY(level, headBase), headBase.z);
        Vec3 mouthAt = headBase.add(0, 2.6, 0).add(fwd.scale(0.9));
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        Vec3 aimAt = target != null ? target.getBoundingBox().getCenter() : aim(p, 30);
        float dmg = JutsuUtil.dmg(6f);
        Fx.line(level, Fx.Visual.EARTH_DRAGON, headBase, headBase.add(fwd), 1f, 46);
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
        level.sendParticles(dirt, headBase.x, headBase.y + 0.3, headBase.z, 60, 0.8, 0.3, 0.8, 0.2);
        JutsuUtil.sound(level, headBase, SoundEvents.RAVAGER_ROAR, 1.0f, 0.6f);
        for (int k = 0; k < 4; k++) {
            Scheduler.later(10 + k * 6, () -> {
                Vec3 goal = target != null && target.isAlive() ? target.getBoundingBox().getCenter() : aimAt;
                int ticks = travel(level, p, mouthAt, goal, null, 1.6, 1.0, false, false, (e, at) -> {
                    hurt(level, p, e, dmg);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                }, end -> {
                    level.sendParticles(MUD_DUST, end.x, end.y, end.z, 30, 0.5, 0.5, 0.5, 0.0);
                    level.sendParticles(dirt, end.x, end.y, end.z, 20, 0.4, 0.4, 0.4, 0.1);
                    JutsuUtil.sound(level, end, SoundEvents.MUD_BREAK, 1.2f, 0.7f);
                }, null);
                Fx.line(level, Fx.Visual.MUD_BULLET, mouthAt, goal, 1f, ticks + 1);
                JutsuUtil.sound(level, mouthAt, SoundEvents.SLIME_SQUISH, 1.5f, 0.5f);
            });
        }
        return true;
    }

    /** Earth Sandwich: two great slabs of earth rise on either side of the target and slam together on them. */
    public static boolean earthSandwich(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        Vec3 aimAt = target != null ? target.position() : aim(p, 24);
        Vec3 ground = new Vec3(aimAt.x, groundY(level, aimAt), aimAt.z);
        Vec3 side = new Vec3(-flatLook(p).z, 0, flatLook(p).x);
        float dmg = JutsuUtil.dmg(18f);
        Fx.line(level, Fx.Visual.EARTH_SANDWICH, ground, ground.add(side), 1f, 44);
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.COARSE_DIRT.defaultBlockState());
        for (int s = -1; s <= 1; s += 2) {
            Vec3 at = ground.add(side.scale(4 * s));
            level.sendParticles(dirt, at.x, at.y + 0.2, at.z, 40, 0.5, 0.3, 2.0, 0.15);
        }
        JutsuUtil.sound(level, ground, SoundEvents.WARDEN_DIG, 1.5f, 0.7f);
        Scheduler.later(17, () -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, ground.add(0, 1, 0), 2.8)) {
                hurt(level, p, e, dmg);
                Afflictions.stun(e, 40, Afflictions.STUN_NONE);
            }
            level.sendParticles(dirt, ground.x, ground.y + 2, ground.z, 120, 0.4, 2.0, 2.0, 0.25);
            JutsuUtil.sound(level, ground, SoundEvents.GENERIC_EXPLODE, 1.6f, 0.5f);
            JutsuUtil.sound(level, ground, SoundEvents.ANVIL_LAND, 1.5f, 0.4f);
        });
        return true;
    }

    /**
     * Rock Golem: a stone giant rises out of the ground near the target, draws back its fist and smashes it down on
     * them, then crumbles back into the earth.
     */
    public static boolean rockGolem(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        Vec3 aimAt = target != null ? target.position() : aim(p, 32);
        Vec3 hitAt = new Vec3(aimAt.x, groundY(level, aimAt), aimAt.z);
        Vec3 fwd = flatLook(p);
        Vec3 feet = hitAt.subtract(fwd.scale(6.5));
        feet = new Vec3(feet.x, groundY(level, feet), feet.z);
        float dmg = JutsuUtil.dmg(26f);
        Fx.line(level, Fx.Visual.ROCK_GOLEM, feet, hitAt, 1f, 74);
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        level.sendParticles(stone, feet.x, feet.y + 0.3, feet.z, 100, 2.0, 0.3, 2.0, 0.2);
        JutsuUtil.sound(level, feet, SoundEvents.WARDEN_EMERGE, 2.0f, 0.7f);
        Vec3 f = feet;
        Scheduler.later(38, () -> {
            Vec3 at = target != null && target.isAlive() && target.position().distanceTo(hitAt) < 4 ? target.position() : hitAt;
            for (LivingEntity e : JutsuUtil.inRadius(level, p, at.add(0, 1, 0), 5)) {
                hurt(level, p, e, dmg);
                JutsuUtil.push(e, away(at, e).scale(0.7).add(0, 0.9, 0));
            }
            level.sendParticles(stone, at.x, at.y + 0.5, at.z, 200, 3.0, 0.8, 3.0, 0.3);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y + 0.5, at.z, 1, 0, 0, 0, 0);
            JutsuUtil.sound(level, at, SoundEvents.GENERIC_EXPLODE, 2.5f, 0.4f);
            JutsuUtil.sound(level, at, SoundEvents.ANVIL_LAND, 2.0f, 0.3f);
        });
        Scheduler.later(58, () -> JutsuUtil.sound(level, f, SoundEvents.STONE_BREAK, 2.0f, 0.4f));
        return true;
    }

    // ================================================================ water

    /**
     * Hiding in Mist: a thick white mist rolls out around you (12 blocks) for 20 seconds. Anyone else inside is blinded
     * and creatures lose track of you; you're unseen while you're in it.
     */
    public static boolean hidingInMist(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 centre = p.position();
        double radius = 12;
        Fx.at(level, Fx.Visual.MIST, centre, (float) radius, 400);
        Scheduler.repeat(0, 10, 40, i -> {
            double r = radius * JutsuUtil.size();
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(centre, centre).inflate(r))) {
                if (e.position().distanceTo(centre) > r || !e.isAlive()) continue;
                if (e == p) {
                    p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 25, 0, false, false, false));
                    continue;
                }
                if (!JutsuUtil.isValidTarget(p, e)) continue;
                e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false, false));
                if (e instanceof Mob mob && mob.getTarget() == p) mob.setTarget(null);
            }
        });
        JutsuUtil.sound(level, centre, SoundEvents.FIRE_EXTINGUISH, 1.5f, 0.4f);
        JutsuUtil.sound(level, centre, SoundEvents.AMBIENT_UNDERWATER_ENTER, 1.5f, 0.8f);
        return true;
    }

    // ---------------------------------------------------------------- Flying Thunder God (the jutsu)

    /**
     * Flying Thunder God as a jutsu (Ninjutsu, from its scroll): Sneak + cast writes your seal on the block you look at;
     * cast flashes you to the mark you're aiming at, or else to the last one you made. (Only the Namikaze use the kunai.)
     */
    public static boolean flyingThunderGod(ServerPlayer p, NinjaData d) {
        if (p.isShiftKeyDown()) {
            net.minecraft.world.phys.BlockHitResult hit = JutsuUtil.rayBlock(p, 6);
            if (hit.getType() != net.minecraft.world.phys.HitResult.Type.BLOCK) {
                p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.ftg_seal_aim")
                        .withStyle(net.minecraft.ChatFormatting.GRAY), true);
                return false;
            }
            com.shinobiarts.ninja.FlyingThunderGod.seal(p, hit.getBlockPos(), hit.getDirection());
            return true;
        }
        com.shinobiarts.ninja.FlyingThunderGod.Mark m = com.shinobiarts.ninja.FlyingThunderGod.aimed(p, d);
        if (m == null && !d.ftg.list.isEmpty()) m = d.ftg.list.get(d.ftg.list.size() - 1);
        if (m == null) {
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.ftg_no_marks")
                    .withStyle(net.minecraft.ChatFormatting.GRAY), true);
            return false;
        }
        return com.shinobiarts.ninja.FlyingThunderGod.teleport(p, d, m);
    }

    /** Namikaze: Flying Thunder God strike: a yellow flash, and you're behind whoever you aim at, cutting. */
    public static boolean ftgStrike(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        if (target == null) {
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.no_target")
                    .withStyle(net.minecraft.ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 from = p.position();
        Vec3 facing = Vec3.directionFromRotation(0, target.getYRot());
        Vec3 behind = target.position().subtract(facing.scale(target.getBbWidth() / 2 + 0.9));
        Vec3 safe = JutsuUtil.findSafe(p, behind);
        if (safe == null) safe = target.position();
        Fx.at(level, Fx.Visual.FLYING_THUNDER_GOD, from.add(0, 1, 0), 1f, 10);
        JutsuUtil.teleport(p, safe);
        p.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, target.getEyePosition());
        Fx.at(level, Fx.Visual.FLYING_THUNDER_GOD, safe.add(0, 1, 0), 1f, 10);
        target.invulnerableTime = 0;
        hurt(level, p, target, JutsuUtil.dmg(14f));
        JutsuUtil.push(target, facing.scale(0.9).add(0, 0.3, 0));
        JutsuUtil.sound(level, safe, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.8f);
        JutsuUtil.sound(level, safe, SoundEvents.PLAYER_ATTACK_STRONG, 1.2f, 1.0f);
        return true;
    }
}
